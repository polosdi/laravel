<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Absensi;
use App\Models\JurnalHarian;
use App\Models\NilaiPkl;
use App\Models\PklPengajuan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class DashboardGuruController extends Controller
{
    public function index()
    {
        // Dummy data sementara karena database kosong
        $guru = (object)[
            'id' => 0,
            'nama_depan' => 'Guru',
            'nama_belakang' => 'Pembimbing',
            'email' => 'guru@simpkl.com',
            'role' => 'pembimbing',
        ];

        $totalSiswa = 0;
        $hadirHariIni = 0;
        $jurnalPending = 0;
        $persentaseHadir = 0;
        $jurnalTerbaru = collect();
        $absensiTerbaru = collect();
        $totalNilaiDiinput = 0;
        $siswaBelumdNilai = 0;
        $jurnalBulanIni = 0;
        $siswaBimbingan = collect();

        return view('guru', compact(
            'guru',
            'totalSiswa',
            'hadirHariIni',
            'jurnalPending',
            'persentaseHadir',
            'jurnalTerbaru',
            'absensiTerbaru',
            'totalNilaiDiinput',
            'siswaBelumdNilai',
            'jurnalBulanIni',
            'siswaBimbingan'
        ));
    }

    // public function index()
    // {
    //     $guru = Auth::user();

    //     // Siswa yang dibimbing oleh guru ini (lewat pkl_pengajuan)
    //     $pengajuanDibimbing = PklPengajuan::where('pembimbing_id', $guru->id)
    //         ->where('status_pembimbing', 'disetujui')
    //         ->with('anggota.siswa.profilSiswa')
    //         ->get();

    //     // Kumpulkan semua siswa bimbingan
    //     $siswaBimbingan = collect();
    //     foreach ($pengajuanDibimbing as $pengajuan) {
    //         foreach ($pengajuan->anggota as $anggota) {
    //             if ($anggota->siswa) {
    //                 $siswaBimbingan->push($anggota->siswa);
    //             }
    //         }
    //     }
    //     $siswaBimbingan = $siswaBimbingan->unique('id');
    //     $totalSiswa = $siswaBimbingan->count();
    //     $siswaIds = $siswaBimbingan->pluck('id');

    //     // Statistik absensi hari ini
    //     $today = Carbon::today()->toDateString();
    //     $hadirHariIni = Absensi::whereIn('siswa_id', $siswaIds)
    //         ->where('tanggal', $today)
    //         ->where('status', 'Hadir')
    //         ->count();

    //     // Jurnal pending validasi
    //     $jurnalPending = JurnalHarian::whereIn('siswa_id', $siswaIds)
    //         ->where('status_validasi', 'pending')
    //         ->count();

    //     // Total jurnal bulan ini
    //     $jurnalBulanIni = JurnalHarian::whereIn('siswa_id', $siswaIds)
    //         ->whereMonth('tanggal', Carbon::now()->month)
    //         ->count();

    //     // Persentase kehadiran bulan ini
    //     $totalAbsenBulanIni = Absensi::whereIn('siswa_id', $siswaIds)
    //         ->whereMonth('tanggal', Carbon::now()->month)
    //         ->count();
    //     $hadirBulanIni = Absensi::whereIn('siswa_id', $siswaIds)
    //         ->whereMonth('tanggal', Carbon::now()->month)
    //         ->where('status', 'Hadir')
    //         ->count();
    //     $persentaseHadir = $totalAbsenBulanIni > 0
    //         ? round(($hadirBulanIni / $totalAbsenBulanIni) * 100)
    //         : 0;

    //     // Jurnal terbaru (5 terakhir) untuk ditampilkan
    //     $jurnalTerbaru = JurnalHarian::whereIn('siswa_id', $siswaIds)
    //         ->with('siswa.profilSiswa')
    //         ->orderByDesc('tanggal')
    //         ->limit(5)
    //         ->get();

    //     // Nilai yang sudah diinput
    //     $totalNilaiDiinput = NilaiPkl::where('pembimbing_id', $guru->id)->count();

    //     // Siswa belum dinilai
    //     $siswaBelumdNilai = $totalSiswa - $totalNilaiDiinput;

    //     // Absensi terbaru
    //     $absensiTerbaru = Absensi::whereIn('siswa_id', $siswaIds)
    //         ->with('siswa.profilSiswa')
    //         ->orderByDesc('tanggal')
    //         ->limit(5)
    //         ->get();

    //     return view('dashboard.guru', compact(
    //         'guru',
    //         'totalSiswa',
    //         'hadirHariIni',
    //         'jurnalPending',
    //         'persentaseHadir',
    //         'jurnalTerbaru',
    //         'absensiTerbaru',
    //         'totalNilaiDiinput',
    //         'siswaBelumdNilai',
    //         'jurnalBulanIni',
    //         'siswaBimbingan'
    //     ));
    // }
}