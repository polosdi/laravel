<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardGuruController;
use App\Http\Controllers\WakasekDashboardController;
use App\Http\Controllers\WakasekGuruController;
use App\Http\Controllers\WakasekSiswaController;
use App\Http\Controllers\WakasekMitraController;
use App\Http\Controllers\WakasekPengajuanController;
use App\Http\Controllers\WakasekLaporanController;
use App\Http\Controllers\WakasekAbsensiController;
use App\Http\Controllers\WakasekNilaiController;
use App\Http\Controllers\WakasekLogController;
use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Auth;

Route::post('/logout', function () {
    Auth::logout();
    request()->session()->invalidate();
    request()->session()->regenerateToken();
    return redirect()->route('login');
})->name('logout');

// Tambahkan ini di web.php
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::get('/dashboard/wakasek/nilai', [WakasekNilaiController::class, 'index'])->name('wakasek.nilai');
Route::get('/dashboard/wakasek/log', [WakasekLogController::class, 'index'])->name('wakasek.log');

Route::get('/dashboard/wakasek/absensi', [WakasekAbsensiController::class, 'index'])
    ->name('wakasek.absensi');

Route::get('/dashboard/wakasek/laporan', [WakasekLaporanController::class, 'index'])
    ->name('wakasek.laporan');
Route::patch('/dashboard/wakasek/laporan/{id}/approve', [WakasekLaporanController::class, 'approve'])
    ->name('wakasek.laporan.approve');

Route::get('/dashboard/wakasek/pengajuan', [WakasekPengajuanController::class, 'index'])
    ->name('wakasek.pengajuan');
Route::patch('/dashboard/wakasek/pengajuan/{id}/approve', [WakasekPengajuanController::class, 'approve'])
    ->name('wakasek.pengajuan.approve');
Route::patch('/dashboard/wakasek/pengajuan/{id}/reject', [WakasekPengajuanController::class, 'reject'])
    ->name('wakasek.pengajuan.reject');

Route::get('/dashboard/wakasek/mitra', [WakasekMitraController::class, 'index'])
    ->name('wakasek.mitra');

Route::get('/dashboard/wakasek/siswa', [WakasekSiswaController::class, 'index'])
    ->name('wakasek.siswa');

Route::get('/dashboard/wakasek/guru', [WakasekGuruController::class, 'index'])
    ->name('wakasek.guru');

Route::get('/', function () {
    return view('index');
});

Route::get('/dashboard/guru', [DashboardGuruController::class, 'index'])
    ->name('dashboard.guru');

Route::get('/dashboard/wakasek', [WakasekDashboardController::class, 'index'])
    ->name('dashboard.wakasek');

Route::get('/login', [AuthController::class, 'index'])->name('login');