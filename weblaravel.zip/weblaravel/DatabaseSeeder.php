<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // ──────────────────────────────────────────
        // 1. USERS
        // ──────────────────────────────────────────

        // Wakasek
        $wakasekId = DB::table('users')->insertGetId([
            'nama_depan'  => 'Budi',
            'nama_belakang' => 'Santoso',
            'email'       => 'wakasek@simpkl.com',
            'password'    => Hash::make('password'),
            'role'        => 'wakasek',
        ]);

        // Guru Pembimbing (3 orang)
        $guru1Id = DB::table('users')->insertGetId([
            'nama_depan'  => 'Siti',
            'nama_belakang' => 'Rahayu',
            'email'       => 'siti.rahayu@simpkl.com',
            'password'    => Hash::make('password'),
            'role'        => 'pembimbing',
        ]);
        $guru2Id = DB::table('users')->insertGetId([
            'nama_depan'  => 'Ahmad',
            'nama_belakang' => 'Fauzi',
            'email'       => 'ahmad.fauzi@simpkl.com',
            'password'    => Hash::make('password'),
            'role'        => 'pembimbing',
        ]);
        $guru3Id = DB::table('users')->insertGetId([
            'nama_depan'  => 'Dewi',
            'nama_belakang' => 'Lestari',
            'email'       => 'dewi.lestari@simpkl.com',
            'password'    => Hash::make('password'),
            'role'        => 'pembimbing',
        ]);

        // Siswa (15 orang, 3 kelas)
        $siswas = [
            // Kelas XI RPL 1
            ['nama_depan' => 'Andi',     'nama_belakang' => 'Pratama',   'email' => 'andi.pratama@siswa.com',   'kelas' => 'XI RPL 1', 'jurusan' => 'Rekayasa Perangkat Lunak', 'nis' => '2024001', 'no_hp' => '081234567001'],
            ['nama_depan' => 'Bima',     'nama_belakang' => 'Saputra',   'email' => 'bima.saputra@siswa.com',   'kelas' => 'XI RPL 1', 'jurusan' => 'Rekayasa Perangkat Lunak', 'nis' => '2024002', 'no_hp' => '081234567002'],
            ['nama_depan' => 'Citra',    'nama_belakang' => 'Dewi',      'email' => 'citra.dewi@siswa.com',     'kelas' => 'XI RPL 1', 'jurusan' => 'Rekayasa Perangkat Lunak', 'nis' => '2024003', 'no_hp' => '081234567003'],
            ['nama_depan' => 'Dina',     'nama_belakang' => 'Marlina',   'email' => 'dina.marlina@siswa.com',   'kelas' => 'XI RPL 1', 'jurusan' => 'Rekayasa Perangkat Lunak', 'nis' => '2024004', 'no_hp' => '081234567004'],
            ['nama_depan' => 'Eko',      'nama_belakang' => 'Wahyudi',   'email' => 'eko.wahyudi@siswa.com',    'kelas' => 'XI RPL 1', 'jurusan' => 'Rekayasa Perangkat Lunak', 'nis' => '2024005', 'no_hp' => '081234567005'],
            // Kelas XI TKJ 1
            ['nama_depan' => 'Fajar',    'nama_belakang' => 'Nugroho',   'email' => 'fajar.nugroho@siswa.com',  'kelas' => 'XI TKJ 1', 'jurusan' => 'Teknik Komputer Jaringan', 'nis' => '2024006', 'no_hp' => '081234567006'],
            ['nama_depan' => 'Gita',     'nama_belakang' => 'Puspita',   'email' => 'gita.puspita@siswa.com',   'kelas' => 'XI TKJ 1', 'jurusan' => 'Teknik Komputer Jaringan', 'nis' => '2024007', 'no_hp' => '081234567007'],
            ['nama_depan' => 'Hendra',   'nama_belakang' => 'Kurnia',    'email' => 'hendra.kurnia@siswa.com',  'kelas' => 'XI TKJ 1', 'jurusan' => 'Teknik Komputer Jaringan', 'nis' => '2024008', 'no_hp' => '081234567008'],
            ['nama_depan' => 'Indah',    'nama_belakang' => 'Permata',   'email' => 'indah.permata@siswa.com',  'kelas' => 'XI TKJ 1', 'jurusan' => 'Teknik Komputer Jaringan', 'nis' => '2024009', 'no_hp' => '081234567009'],
            ['nama_depan' => 'Joko',     'nama_belakang' => 'Susanto',   'email' => 'joko.susanto@siswa.com',   'kelas' => 'XI TKJ 1', 'jurusan' => 'Teknik Komputer Jaringan', 'nis' => '2024010', 'no_hp' => '081234567010'],
            // Kelas XI MM 1
            ['nama_depan' => 'Kartika',  'nama_belakang' => 'Sari',      'email' => 'kartika.sari@siswa.com',   'kelas' => 'XI MM 1',  'jurusan' => 'Multimedia',              'nis' => '2024011', 'no_hp' => '081234567011'],
            ['nama_depan' => 'Lukman',   'nama_belakang' => 'Hakim',     'email' => 'lukman.hakim@siswa.com',   'kelas' => 'XI MM 1',  'jurusan' => 'Multimedia',              'nis' => '2024012', 'no_hp' => '081234567012'],
            ['nama_depan' => 'Maya',     'nama_belakang' => 'Anggraini', 'email' => 'maya.anggraini@siswa.com', 'kelas' => 'XI MM 1',  'jurusan' => 'Multimedia',              'nis' => '2024013', 'no_hp' => '081234567013'],
            ['nama_depan' => 'Nanda',    'nama_belakang' => 'Rizki',     'email' => 'nanda.rizki@siswa.com',    'kelas' => 'XI MM 1',  'jurusan' => 'Multimedia',              'nis' => '2024014', 'no_hp' => '081234567014'],
            ['nama_depan' => 'Oscar',    'nama_belakang' => 'Firmansyah','email' => 'oscar.firmansyah@siswa.com','kelas' => 'XI MM 1', 'jurusan' => 'Multimedia',              'nis' => '2024015', 'no_hp' => '081234567015'],
        ];

        $siswaIds = [];
        foreach ($siswas as $s) {
            $uid = DB::table('users')->insertGetId([
                'nama_depan'   => $s['nama_depan'],
                'nama_belakang'=> $s['nama_belakang'],
                'email'        => $s['email'],
                'password'     => Hash::make('password'),
                'role'         => 'siswa',
            ]);
            DB::table('profil_siswa')->insert([
                'user_id'       => $uid,
                'nis'           => $s['nis'],
                'kelas'         => $s['kelas'],
                'jurusan'       => $s['jurusan'],
                'no_hp'         => $s['no_hp'],
                'jenis_kelamin' => in_array($s['nama_depan'], ['Citra','Dina','Gita','Indah','Kartika','Maya']) ? 'Perempuan' : 'Laki-laki',
            ]);
            $siswaIds[] = $uid;
        }

        // ──────────────────────────────────────────
        // 2. PROFIL GURU
        // ──────────────────────────────────────────
        DB::table('profil_guru')->insert([
            ['user_id' => $guru1Id, 'nip' => '198501012010012001', 'jabatan' => 'Guru RPL',  'no_hp' => '082100000001'],
            ['user_id' => $guru2Id, 'nip' => '198703152011011002', 'jabatan' => 'Guru TKJ',  'no_hp' => '082100000002'],
            ['user_id' => $guru3Id, 'nip' => '199001202012012003', 'jabatan' => 'Guru MM',   'no_hp' => '082100000003'],
        ]);

        // ──────────────────────────────────────────
        // 3. MITRA INDUSTRI (6 perusahaan)
        // ──────────────────────────────────────────
        $mitras = [
            ['nama_perusahaan' => 'PT Telkom Indonesia',      'alamat_perusahaan' => 'Jl. Japati No.1, Bandung',         'website' => 'https://telkom.co.id'],
            ['nama_perusahaan' => 'CV Nusantara Digital',     'alamat_perusahaan' => 'Jl. Raya Darmo No.22, Surabaya',   'website' => 'https://nusantaradigital.co.id'],
            ['nama_perusahaan' => 'PT Indosat Ooredoo',       'alamat_perusahaan' => 'Jl. Medan Merdeka Barat, Jakarta', 'website' => 'https://indosatooredoo.com'],
            ['nama_perusahaan' => 'Startup Kreatif Indonesia','alamat_perusahaan' => 'Jl. Braga No.10, Bandung',         'website' => null],
            ['nama_perusahaan' => 'PT Kreasi Media Nusantara','alamat_perusahaan' => 'Jl. Sudirman No.5, Jakarta',       'website' => 'https://kreasimedia.co.id'],
            ['nama_perusahaan' => 'CV Teknologi Mandiri',     'alamat_perusahaan' => 'Jl. Gatot Subroto No.88, Bandung', 'website' => null],
        ];
        foreach ($mitras as $m) {
            DB::table('mitra_industri')->insert($m);
        }

        // ──────────────────────────────────────────
        // 4. PKL PENGAJUAN
        // Skenario:
        //   - 6 disetujui (siswa 0–5 ketua, masing-masing 2 anggota)
        //   - 3 pending
        //   - 2 ditolak
        // ──────────────────────────────────────────
        $perusahaanList = [
            'PT Telkom Indonesia', 'CV Nusantara Digital', 'PT Indosat Ooredoo',
            'Startup Kreatif Indonesia', 'PT Kreasi Media Nusantara', 'CV Teknologi Mandiri',
            'PT Maju Bersama', 'PT Digital Kreatif', 'CV Solusi IT',
            'PT Inovasi Teknologi', 'CV Cipta Karya',
        ];

        $guruList   = [$guru1Id, $guru2Id, $guru3Id];
        $pengajuanIds = [];

        // 6 pengajuan disetujui (siswa index 0,2,4,6,8,10 sebagai ketua)
        $ketuaDisetujui = [0, 2, 4, 6, 8, 10];
        foreach ($ketuaDisetujui as $i => $si) {
            $pid = DB::table('pkl_pengajuan')->insertGetId([
                'ketua_id'          => $siswaIds[$si],
                'nama_perusahaan'   => $perusahaanList[$i],
                'alamat_perusahaan' => 'Jl. Contoh No.' . ($i + 1) . ', Bandung',
                'website'           => 'https://perusahaan' . ($i + 1) . '.com',
                'status_pembimbing' => 'disetujui',
                'status_wakasek'    => 'disetujui',
                'pembimbing_id'     => $guruList[$i % 3],
                'tanggal_pengajuan' => Carbon::now()->subDays(rand(10, 30)),
            ]);
            // anggota: ketua + 1 siswa lain
            DB::table('pkl_anggota')->insert([
                ['pengajuan_id' => $pid, 'siswa_id' => $siswaIds[$si],     'status_keanggotaan' => 'aktif'],
                ['pengajuan_id' => $pid, 'siswa_id' => $siswaIds[$si + 1], 'status_keanggotaan' => 'aktif'],
            ]);
            $pengajuanIds[] = $pid;
        }

        // 3 pengajuan pending
        $ketuaPending = [12, 13, 14];
        foreach ($ketuaPending as $i => $si) {
            $pid = DB::table('pkl_pengajuan')->insertGetId([
                'ketua_id'          => $siswaIds[$si],
                'nama_perusahaan'   => $perusahaanList[6 + $i],
                'alamat_perusahaan' => 'Jl. Pending No.' . ($i + 1) . ', Bandung',
                'website'           => null,
                'status_pembimbing' => 'pending',
                'status_wakasek'    => 'pending',
                'pembimbing_id'     => null,
                'tanggal_pengajuan' => Carbon::now()->subDays(rand(1, 5)),
            ]);
            DB::table('pkl_anggota')->insert([
                ['pengajuan_id' => $pid, 'siswa_id' => $siswaIds[$si], 'status_keanggotaan' => 'aktif'],
            ]);
            $pengajuanIds[] = $pid;
        }

        // 2 pengajuan ditolak
        // gunakan siswa yang belum punya pengajuan (tidak ada, jadi buat ulang dengan siswa yang sama tapi beda pengajuan)
        foreach ([0, 1] as $i) {
            DB::table('pkl_pengajuan')->insertGetId([
                'ketua_id'          => $siswaIds[$i],
                'nama_perusahaan'   => $perusahaanList[9 + $i],
                'alamat_perusahaan' => 'Jl. Ditolak No.' . ($i + 1) . ', Bandung',
                'website'           => null,
                'status_pembimbing' => 'ditolak',
                'status_wakasek'    => 'ditolak',
                'pembimbing_id'     => $guruList[$i],
                'tanggal_pengajuan' => Carbon::now()->subDays(rand(20, 40)),
            ]);
        }

        // ──────────────────────────────────────────
        // 5. ABSENSI (30 hari terakhir untuk 12 siswa aktif PKL)
        // ──────────────────────────────────────────
        $siswaAktif = array_slice($siswaIds, 0, 12); // siswa yang PKL-nya disetujui
        $statusAbsensi = ['Hadir', 'Hadir', 'Hadir', 'Hadir', 'Izin', 'Sakit', 'Alpa'];

        foreach ($siswaAktif as $sid) {
            for ($d = 29; $d >= 0; $d--) {
                $tanggal = Carbon::now()->subDays($d)->toDateString();
                $dayOfWeek = Carbon::now()->subDays($d)->dayOfWeek;
                if ($dayOfWeek == 0 || $dayOfWeek == 6) continue; // skip weekend

                $status = $statusAbsensi[array_rand($statusAbsensi)];
                DB::table('absensi')->insert([
                    'siswa_id'   => $sid,
                    'tanggal'    => $tanggal,
                    'jam_masuk'  => $status === 'Hadir' ? '08:00:00' : null,
                    'jam_pulang' => $status === 'Hadir' ? '16:00:00' : null,
                    'status'     => $status,
                    'keterangan' => $status !== 'Hadir' ? 'Keterangan ' . $status : null,
                ]);
            }
        }

        // ──────────────────────────────────────────
        // 6. LAPORAN PKL
        // ──────────────────────────────────────────
        $judulLaporan = [
            'Laporan PKL Minggu ke-1', 'Laporan PKL Minggu ke-2',
            'Laporan PKL Minggu ke-3', 'Laporan PKL Minggu ke-4',
            'Laporan Akhir PKL',
        ];

        foreach ($siswaAktif as $i => $sid) {
            // 4 laporan mingguan + 1 laporan akhir per siswa
            foreach ($judulLaporan as $j => $judul) {
                $isAkhir = $j === 4;
                // Status bervariasi
                if ($i < 4) {
                    $statusPembimbing = 'disetujui';
                    $statusWakasek    = $isAkhir ? 'disetujui' : ($j < 3 ? 'disetujui' : 'pending');
                } elseif ($i < 8) {
                    $statusPembimbing = $j < 2 ? 'disetujui' : ($j < 4 ? 'revisi' : 'pending');
                    $statusWakasek    = $j < 2 ? 'disetujui' : 'pending';
                } else {
                    $statusPembimbing = $j < 1 ? 'disetujui' : 'pending';
                    $statusWakasek    = $j < 1 ? 'pending' : 'pending';
                }

                DB::table('laporan_pkl')->insert([
                    'siswa_id'          => $sid,
                    'judul_laporan'     => $judul,
                    'file_path'         => null,
                    'jenis_laporan'     => $isAkhir ? 'akhir' : 'mingguan',
                    'status_pembimbing' => $statusPembimbing,
                    'status_wakasek'    => $statusWakasek,
                    'catatan_revisi'    => $statusPembimbing === 'revisi' ? 'Perbaiki bagian deskripsi kegiatan.' : null,
                    'tampil_di_publik'  => false,
                    'created_at'        => Carbon::now()->subDays(rand(1, 25)),
                ]);
            }
        }

        // ──────────────────────────────────────────
        // 7. NILAI PKL (untuk siswa yang pengajuannya disetujui)
        // ──────────────────────────────────────────
        foreach ($siswaAktif as $i => $sid) {
            $sikap         = rand(75, 95);
            $keterampilan  = rand(70, 98);
            $nilaiLaporan  = rand(72, 96);
            $nilaiAkhir    = round(($sikap * 0.3) + ($keterampilan * 0.4) + ($nilaiLaporan * 0.3), 2);
            $predikat      = $nilaiAkhir >= 90 ? 'A' : ($nilaiAkhir >= 80 ? 'B' : ($nilaiAkhir >= 70 ? 'C' : 'D'));

            DB::table('nilai_pkl')->insert([
                'siswa_id'          => $sid,
                'pembimbing_id'     => $guruList[$i % 3],
                'nilai_sikap'       => $sikap,
                'nilai_keterampilan'=> $keterampilan,
                'nilai_laporan'     => $nilaiLaporan,
                'nilai_akhir'       => $nilaiAkhir,
                'predikat'          => $predikat,
                'catatan'           => 'Siswa menunjukkan kinerja yang baik selama PKL.',
                'created_at'        => Carbon::now()->subDays(rand(1, 10)),
            ]);
        }

        // ──────────────────────────────────────────
        // 8. LOG AKTIVITAS
        // ──────────────────────────────────────────
        $logs = [
            ['id_users' => $wakasekId, 'aktivitas' => 'Login ke sistem SIMPKL'],
            ['id_users' => $wakasekId, 'aktivitas' => 'Menyetujui pengajuan PKL Andi Pratama ke PT Telkom Indonesia'],
            ['id_users' => $wakasekId, 'aktivitas' => 'Menyetujui laporan PKL Bima Saputra'],
            ['id_users' => $guru1Id,   'aktivitas' => 'Menginput nilai PKL siswa bimbingan'],
            ['id_users' => $guru2Id,   'aktivitas' => 'Memvalidasi jurnal harian siswa'],
            ['id_users' => $guru3Id,   'aktivitas' => 'Menyetujui laporan mingguan Kartika Sari'],
            ['id_users' => $siswaIds[0], 'aktivitas' => 'Mengajukan permohonan PKL ke PT Telkom Indonesia'],
            ['id_users' => $siswaIds[2], 'aktivitas' => 'Mengunggah laporan PKL minggu ke-1'],
            ['id_users' => $siswaIds[4], 'aktivitas' => 'Melakukan absensi hadir'],
            ['id_users' => $wakasekId, 'aktivitas' => 'Melihat rekap absensi seluruh siswa PKL'],
        ];

        foreach ($logs as $log) {
            DB::table('log_aktivitas')->insert([
                'id_users'  => $log['id_users'],
                'aktivitas' => $log['aktivitas'],
                'waktu'     => Carbon::now()->subMinutes(rand(1, 2000)),
            ]);
        }
    }
}