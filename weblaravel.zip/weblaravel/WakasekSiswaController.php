<?php

namespace App\Http\Controllers;

use App\Models\User;

class WakasekSiswaController extends Controller
{
    public function index()
    {
        $siswas = User::where('role', 'siswa')
            ->with(['profilSiswa', 'pengajuanSebagaiKetua'])
            ->orderBy('nama_depan')
            ->get();

        // Tambahkan status PKL ke tiap siswa
        $siswas->each(function ($siswa) {
            $pengajuan = $siswa->pengajuanSebagaiKetua->first();
            if (!$pengajuan) {
                $siswa->statusPkl = 'belum';
            } elseif ($pengajuan->status_wakasek === 'disetujui') {
                $siswa->statusPkl = 'pkl';
            } elseif ($pengajuan->status_wakasek === 'ditolak') {
                $siswa->statusPkl = 'ditolak';
            } else {
                $siswa->statusPkl = 'pending';
            }
        });

        // Kelompokkan per kelas
        $siswaPerKelas = $siswas->groupBy(fn($s) => $s->profilSiswa->kelas ?? 'Tidak Ada Kelas')
            ->sortKeys();

        $totalSiswa = $siswas->count();

        return view('wakasek.siswa', compact('siswaPerKelas', 'totalSiswa'));
    }
}