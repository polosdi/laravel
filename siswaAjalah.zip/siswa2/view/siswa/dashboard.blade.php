@extends('layouts.siswa')

@section('title', 'Dashboard Siswa')
@section('page_title', 'Dashboard')
@section('nav_dashboard', 'active')

@section('styles')
<style>
/* ── WELCOME BANNER ── */
.welcome-banner {
    background: var(--grad);
    border-radius: 16px;
    padding: 24px 28px;
    margin-bottom: 22px;
    position: relative;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
}
.welcome-banner::before {
    content: '';
    position: absolute;
    top: -60px; right: -60px;
    width: 240px; height: 240px;
    background: rgba(255,255,255,.08);
    border-radius: 50%;
}
.welcome-banner::after {
    content: '';
    position: absolute;
    bottom: -80px; left: 30%;
    width: 300px; height: 300px;
    background: rgba(255,255,255,.05);
    border-radius: 50%;
}
.greeting {
    font-size: .75rem;
    color: rgba(255,255,255,.75);
    font-weight: 500;
}
.student-name {
    font-size: 1.45rem;
    font-weight: 800;
    color: white;
    line-height: 1.15;
    margin: 4px 0 10px;
}
.student-meta {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}
.meta-chip {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-size: .72rem;
    font-weight: 600;
    color: rgba(255,255,255,.88);
    background: rgba(255,255,255,.14);
    padding: 4px 10px;
    border-radius: 20px;
}
.pkl-status-badge {
    display: flex;
    flex-direction: column;
    align-items: center;
    background: rgba(255,255,255,.14);
    border: 1.5px solid rgba(255,255,255,.25);
    border-radius: 14px;
    padding: 16px 22px;
    text-align: center;
    z-index: 1;
    flex-shrink: 0;
}
.pkl-status-badge .status-label {
    font-size: .68rem;
    color: rgba(255,255,255,.7);
    font-weight: 600;
    margin-bottom: 4px;
}
.pkl-status-badge .status-value {
    font-size: 1rem;
    font-weight: 800;
    color: white;
}
.status-dot-aktif {
    width: 8px; height: 8px;
    background: #22c55e;
    border-radius: 50%;
    display: inline-block;
    margin-right: 5px;
    animation: pulse 2s infinite;
}
@keyframes pulse {
    0%,100% { opacity:1; transform:scale(1) }
    50% { opacity:.5; transform:scale(1.4) }
}

/* ── STATS ── */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(4,1fr);
    gap: 16px;
    margin-bottom: 22px;
}

/* ── CONTENT GRID ── */
.content-grid {
    display: grid;
    grid-template-columns: 1fr 320px;
    gap: 20px;
    margin-bottom: 20px;
}
.bottom-grid {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 20px;
}

/* ── JURNAL LIST ── */
.jurnal-list { list-style: none; }
.jurnal-item {
    display: flex;
    gap: 14px;
    padding: 12px 0;
    border-bottom: 1px solid var(--border);
}
.jurnal-item:last-child { border-bottom: none; }
.jurnal-date {
    flex-shrink: 0;
    width: 42px;
    text-align: center;
}
.jurnal-date .day {
    font-size: 1.25rem;
    font-weight: 800;
    color: var(--primary);
    line-height: 1;
}
.jurnal-date .month {
    font-size: .6rem;
    text-transform: uppercase;
    letter-spacing: .05em;
    color: var(--text-sub);
    font-weight: 600;
}
.jurnal-body { flex: 1; }
.jurnal-kegiatan {
    font-size: .82rem;
    font-weight: 500;
    color: var(--text);
    margin-bottom: 4px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
.jurnal-meta {
    display: flex;
    gap: 8px;
    align-items: center;
    flex-wrap: wrap;
}
.jurnal-time { font-size: .7rem; color: var(--text-muted); }

/* ── PKL INFO LIST ── */
.pkl-info-list { list-style: none; }
.pkl-info-item {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    padding: 9px 0;
    border-bottom: 1px solid var(--border);
    gap: 12px;
}
.pkl-info-item:last-child { border-bottom: none; }
.pkl-info-key { font-size: .72rem; color: var(--text-muted); font-weight: 500; flex-shrink: 0; }
.pkl-info-val { font-size: .82rem; font-weight: 600; color: var(--text); text-align: right; }

/* ── PROGRESS ── */
.progress-section { margin-bottom: 18px; }
.progress-section .progress-label {
    display: flex;
    justify-content: space-between;
    font-size: .7rem;
    color: var(--text-muted);
    margin-bottom: 6px;
}

/* ── NILAI ── */
.nilai-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.nilai-item {
    background: var(--tag-bg);
    border-radius: 12px;
    padding: 12px 14px;
    border: 1px solid var(--border);
}
.nilai-item .n-label { font-size: .7rem; color: var(--text-muted); font-weight: 500; margin-bottom: 4px; }
.nilai-item .n-val {
    font-size: 1.55rem;
    font-weight: 800;
    color: var(--text);
}
.nilai-akhir {
    background: var(--tag-bg);
    border: 1.5px solid var(--border);
    border-radius: 12px;
    padding: 14px 18px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-top: 10px;
}
.nilai-akhir .val {
    font-size: 1.9rem;
    font-weight: 800;
    background: var(--grad);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

/* ── LAPORAN ── */
.laporan-list { list-style: none; }
.laporan-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 0;
    border-bottom: 1px solid var(--border);
}
.laporan-item:last-child { border-bottom: none; }
.laporan-icon {
    width: 36px; height: 36px;
    border-radius: 10px;
    background: var(--tag-bg);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 17px;
    flex-shrink: 0;
    border: 1px solid var(--border);
}
.laporan-info { flex: 1; }
.laporan-info .l-title { font-size: .8rem; font-weight: 600; color: var(--text); margin-bottom: 2px; }
.laporan-info .l-meta { font-size: .7rem; color: var(--text-muted); }
.btn-upload {
    padding: 6px 12px;
    background: var(--tag-bg);
    border: 1.5px solid var(--border);
    border-radius: 20px;
    font-size: .7rem;
    font-weight: 600;
    color: var(--primary);
    cursor: pointer;
    font-family: var(--font);
    transition: all .2s;
    text-decoration: none;
    white-space: nowrap;
}
.btn-upload:hover { background: rgba(102,126,234,.12); border-color: var(--primary); }

/* ── ABSENSI TABLE ── */
.table-wrap { overflow-x: auto; }
table { width: 100%; border-collapse: collapse; font-size: .78rem; }
thead th {
    text-align: left;
    padding: 8px 10px;
    font-size: .68rem;
    font-weight: 700;
    color: var(--text-sub);
    text-transform: uppercase;
    letter-spacing: .05em;
    border-bottom: 1px solid var(--border);
}
tbody td {
    padding: 9px 10px;
    border-bottom: 1px solid var(--border);
    color: var(--text);
}
tbody tr:last-child td { border-bottom: none; }
tbody tr:hover { background: var(--tag-bg); }

/* ── BADGE (tambahan status) ── */
.badge.badge-disetujui  { background: rgba(34,197,94,.1);   color: #22c55e; }
.badge.badge-pending    { background: rgba(245,158,11,.1);  color: #f59e0b; }
.badge.badge-ditolak    { background: rgba(239,68,68,.1);   color: #ef4444; }
.badge.badge-hadir      { background: rgba(34,197,94,.1);   color: #22c55e; }
.badge.badge-izin       { background: rgba(59,130,246,.1);  color: #3b82f6; }
.badge.badge-sakit      { background: rgba(245,158,11,.1);  color: #f59e0b; }
.badge.badge-alpha      { background: rgba(239,68,68,.1);   color: #ef4444; }
.badge.badge-tervalidasi { background: rgba(34,197,94,.1);  color: #22c55e; }
.badge.badge-belum_validasi { background: rgba(245,158,11,.1); color: #f59e0b; }

/* ── CARD TITLE (compat dengan layouts.app lama) ── */
.card-title { font-size: .9rem; font-weight: 700; color: var(--text); transition: color .4s; }
.card-link { font-size: .75rem; color: var(--primary); font-weight: 600; text-decoration: none; }
.card-link:hover { color: #764ba2; }
.card-body { /* no extra padding needed */ }

@media(max-width:1200px) {
    .stats-grid { grid-template-columns: repeat(2,1fr); }
    .content-grid { grid-template-columns: 1fr; }
    .bottom-grid { grid-template-columns: 1fr 1fr; }
}
@media(max-width:768px) {
    .stats-grid { grid-template-columns: 1fr 1fr; }
    .bottom-grid { grid-template-columns: 1fr; }
    .welcome-banner { flex-direction: column; gap: 16px; }
    .pkl-status-badge { align-self: stretch; }
}
</style>
@endsection

@section('content')

{{-- ── PAGE HEADER ── --}}
<div class="page-header">
    <div>
        <div class="page-title">Selamat Datang, {{ Auth::user()->namaLengkap() }}! 👋</div>
        <div class="page-sub">{{ now()->isoFormat('dddd, D MMMM Y') }}</div>
    </div>
    <div class="page-actions">
        <a href="{{ route('siswa.jurnal.create') }}" class="btn-primary">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Tambah Jurnal
        </a>
    </div>
</div>

{{-- ── WELCOME BANNER ── --}}
<div class="welcome-banner">
    <div class="welcome-text" style="position:relative;z-index:1">
        <div class="greeting">Halo, Siswa!</div>
        <div class="student-name">{{ Auth::user()->namaLengkap() }}</div>
        <div class="student-meta">
            <span class="meta-chip">🏫 {{ $siswa?->jurusan ?? 'Belum diisi' }}</span>
            <span class="meta-chip">🎓 {{ $siswa?->kelas ?? '-' }}</span>
            <span class="meta-chip">🔖 NIS {{ $siswa?->nis ?? '-' }}</span>
            @if($pkl && $pkl->status_wakasek === 'disetujui')
                <span class="meta-chip">🏢 {{ $pkl->nama_perusahaan }}</span>
            @endif
        </div>
    </div>

    @if($pkl && $pkl->status_wakasek === 'disetujui')
        <div class="pkl-status-badge">
            <div class="status-label">Status PKL</div>
            <div class="status-value"><span class="status-dot-aktif"></span>Aktif</div>
            <div style="font-size:.68rem;color:rgba(255,255,255,.65);margin-top:4px">
                Sisa ~{{ $sisiHari ?? '??' }} hari
            </div>
        </div>
    @elseif($pkl)
        <div class="pkl-status-badge">
            <div class="status-label">Status PKL</div>
            <div class="status-value" style="color:#fcd34d;">Menunggu</div>
            <div style="font-size:.68rem;color:rgba(255,255,255,.65);margin-top:4px">
                {{ ucfirst($pkl->status_pembimbing) }} / {{ ucfirst($pkl->status_wakasek) }}
            </div>
        </div>
    @else
        <div class="pkl-status-badge">
            <div class="status-label">Status PKL</div>
            <div class="status-value" style="color:#fcd34d;">Belum Aktif</div>
            <a href="{{ route('siswa.pkl.pengajuan') }}" style="font-size:.68rem;color:rgba(255,255,255,.75);margin-top:4px;text-decoration:none">
                Ajukan sekarang →
            </a>
        </div>
    @endif
</div>

{{-- ── STAT CARDS ── --}}
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-card-top">
            <div class="stat-icon purple">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
            </div>
            <span class="stat-badge info">{{ $jurnalValid }} valid</span>
        </div>
        <div class="stat-num">{{ $totalJurnal }}</div>
        <div class="stat-label">Jurnal Harian</div>
    </div>

    <div class="stat-card">
        <div class="stat-card-top">
            <div class="stat-icon green">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
            </div>
            <span class="stat-badge up">{{ $skorAbsen }}%</span>
        </div>
        <div class="stat-num">{{ $hadir }}</div>
        <div class="stat-label">Hari Hadir</div>
    </div>

    <div class="stat-card">
        <div class="stat-card-top">
            <div class="stat-icon amber">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
            </div>
            <span class="stat-badge warn">{{ $laporanDisetujui }} disetujui</span>
        </div>
        <div class="stat-num">{{ $laporanCount }}</div>
        <div class="stat-label">Laporan Dikirim</div>
    </div>

    <div class="stat-card">
        <div class="stat-card-top">
            <div class="stat-icon pink">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            </div>
            <span class="stat-badge info">{{ $predikat ?? '—' }}</span>
        </div>
        <div class="stat-num">{{ $nilaiAkhir ? number_format($nilaiAkhir, 0) : '—' }}</div>
        <div class="stat-label">Nilai Akhir PKL</div>
    </div>
</div>

{{-- ── JURNAL + INFO PKL ── --}}
<div class="content-grid">

    {{-- Jurnal Harian Terkini --}}
    <div class="card">
        <div class="card-header">
            <div>
                <div class="card-title-sm">Jurnal Harian Terkini</div>
                <div class="card-subtitle">Aktivitas harian kamu</div>
            </div>
            <div style="display:flex;gap:8px;align-items:center">
                <a href="{{ route('siswa.jurnal') }}" class="card-action">Lihat semua →</a>
                <a href="{{ route('siswa.jurnal.create') }}" class="btn-primary" style="padding:7px 14px;font-size:.75rem">+ Tambah</a>
            </div>
        </div>
        @forelse($jurnals as $jurnal)
        <ul class="jurnal-list">
            <li class="jurnal-item">
                <div class="jurnal-date">
                    <div class="day">{{ $jurnal->tanggal->format('d') }}</div>
                    <div class="month">{{ $jurnal->tanggal->format('M') }}</div>
                </div>
                <div class="jurnal-body">
                    <div class="jurnal-kegiatan">{{ $jurnal->kegiatan }}</div>
                    <div class="jurnal-meta">
                        @if($jurnal->jam_masuk)
                            <span class="jurnal-time">⏰ {{ $jurnal->jamMasukFormatted() }} – {{ $jurnal->jamKeluarFormatted() }}</span>
                        @endif
                        <span class="badge badge-{{ $jurnal->status_validasi }}">{{ ucfirst($jurnal->status_validasi) }}</span>
                    </div>
                </div>
            </li>
        </ul>
        @empty
        <div style="text-align:center;padding:32px 0;color:var(--text-muted)">
            <div style="font-size:2rem;margin-bottom:8px">📓</div>
            <div style="font-size:.8rem">Belum ada jurnal. Yuk tambahkan!</div>
        </div>
        @endforelse
    </div>

    {{-- Info PKL --}}
    <div style="display:flex;flex-direction:column;gap:16px">
        <div class="card">
            <div class="card-header">
                <div class="card-title-sm">Informasi PKL</div>
                <a href="{{ route('siswa.pkl.pengajuan') }}" class="card-action">Detail →</a>
            </div>
            @if($pkl)
                @if($pkl->status_wakasek === 'disetujui')
                <div class="progress-section">
                    <div class="progress-label">
                        <span>Progres Waktu PKL</span>
                        <span>{{ $persen }}%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width:{{ $persen }}%"></div>
                    </div>
                </div>
                @endif
                <ul class="pkl-info-list">
                    <li class="pkl-info-item">
                        <span class="pkl-info-key">Perusahaan</span>
                        <span class="pkl-info-val">{{ $pkl->nama_perusahaan }}</span>
                    </li>
                    <li class="pkl-info-item">
                        <span class="pkl-info-key">Pembimbing</span>
                        <span class="pkl-info-val">{{ $pembimbing?->namaLengkap() ?? 'Belum ditentukan' }}</span>
                    </li>
                    <li class="pkl-info-item">
                        <span class="pkl-info-key">Tgl Pengajuan</span>
                        <span class="pkl-info-val">{{ $pkl->tanggal_pengajuan?->format('d M Y') ?? '-' }}</span>
                    </li>
                    <li class="pkl-info-item">
                        <span class="pkl-info-key">Status</span>
                        <span class="pkl-info-val">
                            <span class="badge badge-{{ $pkl->status_wakasek === 'disetujui' ? 'disetujui' : 'pending' }}">
                                {{ ucfirst($pkl->status_wakasek) }}
                            </span>
                        </span>
                    </li>
                </ul>
            @else
                <div style="text-align:center;padding:24px 0;color:var(--text-muted)">
                    <div style="font-size:1.8rem;margin-bottom:8px">📋</div>
                    <div style="font-size:.75rem;margin-bottom:12px">Kamu belum mengajukan PKL.</div>
                    <a href="{{ route('siswa.pkl.pengajuan.create') }}" class="btn-primary" style="font-size:.75rem">+ Ajukan PKL</a>
                </div>
            @endif
        </div>
    </div>
</div>

{{-- ── ABSENSI + NILAI + LAPORAN ── --}}
<div class="bottom-grid">

    {{-- Absensi --}}
    <div class="card">
        <div class="card-header">
            <div>
                <div class="card-title-sm">Absensi Terkini</div>
            </div>
            <a href="{{ route('siswa.absensi') }}" class="card-action">Semua →</a>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr><th>Tanggal</th><th>Masuk</th><th>Pulang</th><th>Status</th></tr>
                </thead>
                <tbody>
                    @forelse($absensi as $abs)
                    <tr>
                        <td>{{ $abs->tanggal->format('d M') }}</td>
                        <td>{{ $abs->jamMasukFormatted() }}</td>
                        <td>{{ $abs->jamPulangFormatted() }}</td>
                        <td><span class="badge badge-{{ strtolower($abs->status) }}">{{ $abs->status }}</span></td>
                    </tr>
                    @empty
                    <tr><td colspan="4" style="text-align:center;color:var(--text-muted);padding:20px">Belum ada data absensi</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    {{-- Nilai PKL --}}
    <div class="card">
        <div class="card-header">
            <div class="card-title-sm">Nilai PKL</div>
            <a href="{{ route('siswa.nilai') }}" class="card-action">Detail →</a>
        </div>
        @if($nilai)
            <div class="nilai-grid">
                <div class="nilai-item"><div class="n-label">Sikap</div><div class="n-val">{{ $nilai->nilai_sikap }}</div></div>
                <div class="nilai-item"><div class="n-label">Keterampilan</div><div class="n-val">{{ $nilai->nilai_keterampilan }}</div></div>
                <div class="nilai-item"><div class="n-label">Laporan</div><div class="n-val">{{ $nilai->nilai_laporan }}</div></div>
                <div class="nilai-item"><div class="n-label">Predikat</div><div class="n-val" style="font-size:1.2rem">{{ $nilai->predikat ?? '—' }}</div></div>
            </div>
            <div class="nilai-akhir">
                <span style="font-size:.82rem;font-weight:600;color:var(--text)">Nilai Akhir</span>
                <span class="val">{{ $nilai->nilai_akhir ? number_format($nilai->nilai_akhir,1) : '—' }}</span>
            </div>
            @if($nilai->catatan)
            <div style="margin-top:10px;padding:10px 12px;background:var(--tag-bg);border-radius:10px;font-size:.72rem;color:var(--text-muted);border:1px solid var(--border)">
                💬 <em>{{ $nilai->catatan }}</em>
            </div>
            @endif
        @else
            <div style="text-align:center;padding:28px 0;color:var(--text-muted)">
                <div style="font-size:2rem;margin-bottom:8px">⭐</div>
                <div style="font-size:.75rem">Nilai belum diinput pembimbing.</div>
            </div>
        @endif
    </div>

    {{-- Laporan PKL --}}
    <div class="card">
        <div class="card-header">
            <div class="card-title-sm">Laporan PKL</div>
            <a href="{{ route('siswa.laporan') }}" class="card-action">Kelola →</a>
        </div>
        <ul class="laporan-list">
            @forelse($laporans as $lap)
            <li class="laporan-item">
                <div class="laporan-icon">{{ $lap->icon() }}</div>
                <div class="laporan-info">
                    <div class="l-title">{{ $lap->judul() }}</div>
                    <div class="l-meta">{{ ucfirst($lap->jenis_laporan) }} · <span class="badge badge-{{ $lap->status_pembimbing }}">{{ ucfirst($lap->status_pembimbing) }}</span></div>
                </div>
                @if($lap->file_path)
                    <a href="{{ $lap->fileUrl() }}" class="btn-upload" target="_blank">⬇ Unduh</a>
                @else
                    <a href="{{ route('siswa.laporan.show', $lap->id) }}" class="btn-upload">⬆ Upload</a>
                @endif
            </li>
            @empty
            <li style="text-align:center;padding:24px 0;color:var(--text-muted)">
                <div style="font-size:1.8rem;margin-bottom:8px">📄</div>
                <div style="font-size:.75rem">Belum ada laporan dikirim.</div>
            </li>
            @endforelse
        </ul>
    </div>

</div>

@endsection