@extends('layouts.siswa')
@section('title','Profil Saya')
@section('page_title','Profil Saya')
@section('nav_profil','active')

@section('styles')
<style>
/* ── PROFIL GRID ── */
.profil-grid {
    display: grid;
    grid-template-columns: 280px 1fr;
    gap: 20px;
    align-items: start;
}

/* ── FOTO CARD ── */
.foto-avatar-wrap {
    width: 90px; height: 90px;
    margin: 0 auto 16px;
    position: relative;
}
.foto-avatar-img {
    width: 90px; height: 90px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid var(--border);
}
.foto-avatar-initials {
    width: 90px; height: 90px;
    background: var(--grad);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-weight: 800; font-size: 1.6rem; color: white;
}
.foto-name {
    font-weight: 800;
    font-size: .95rem;
    color: var(--text);
    line-height: 1.2;
}
.foto-role {
    font-size: .72rem;
    color: var(--primary);
    font-weight: 600;
    margin-top: 4px;
}
.foto-jurusan {
    font-size: .72rem;
    color: var(--text-muted);
    margin-top: 4px;
}
.foto-nis {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
    margin-top: 14px;
    font-size: .72rem;
}
.foto-nis-label { color: var(--text-muted); }
.foto-nis-val { font-weight: 700; color: var(--text); }

/* ── SECTION DIVIDER ── */
.form-section-label {
    font-size: .65rem;
    font-weight: 700;
    letter-spacing: .07em;
    text-transform: uppercase;
    color: var(--text-sub);
    margin-bottom: 12px;
    padding-bottom: 6px;
    border-bottom: 1px solid var(--border);
}

/* ── FORM GRID VARIANTS ── */
.form-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 22px; }
.form-grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 14px; margin-bottom: 22px; }
.col-full { grid-column: 1 / -1; }

/* ── FORM CONTROLS (matching siswa theme) ── */
.form-group { display: flex; flex-direction: column; gap: 5px; }
.form-label {
    font-size: .75rem;
    font-weight: 600;
    color: var(--text-muted);
}
.form-label span { color: var(--primary); }
.form-control {
    padding: 9px 12px;
    border-radius: 10px;
    border: 1.5px solid var(--border);
    background: var(--bg);
    color: var(--text);
    font-size: .82rem;
    font-family: var(--font);
    transition: border-color .18s, box-shadow .18s;
    outline: none;
    width: 100%;
}
.form-control:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(102,126,234,.12);
}
.form-control:disabled {
    background: var(--tag-bg);
    color: var(--text-muted);
    cursor: not-allowed;
}
.form-control.is-invalid { border-color: #ef4444; }
.invalid-feedback { font-size: .7rem; color: #ef4444; margin-top: 2px; }
.form-hint { font-size: .68rem; color: var(--text-sub); margin-top: 2px; }

select.form-control { cursor: pointer; }
textarea.form-control { resize: vertical; }

/* ── FOOTER ACTIONS ── */
.form-footer {
    display: flex;
    gap: 10px;
    justify-content: flex-end;
    padding-top: 6px;
    border-top: 1px solid var(--border);
    margin-top: 4px;
}

/* ── PASSWORD CARD ── */
.pass-card-title {
    font-size: .82rem;
    font-weight: 700;
    color: var(--text);
    display: flex;
    align-items: center;
    gap: 6px;
}

@media (max-width: 960px) {
    .profil-grid { grid-template-columns: 1fr; }
    .form-grid-3 { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 600px) {
    .form-grid-2,
    .form-grid-3 { grid-template-columns: 1fr; }
}
</style>
@endsection

@section('content')
<div class="profil-grid">

    {{-- ── KOLOM KIRI: Foto + Password ── --}}
    <div style="display:flex;flex-direction:column;gap:16px">

        {{-- Kartu Foto Profil --}}
        <div class="card">
            <div class="card-body" style="text-align:center;padding:28px 20px 16px">
                <div class="foto-avatar-wrap">
                    @if($siswa?->foto_profil)
                        <img src="{{ asset('storage/'.$siswa->foto_profil) }}"
                             class="foto-avatar-img" alt="Foto Profil">
                    @else
                        <div class="foto-avatar-initials">{{ $user->inisial() }}</div>
                    @endif
                </div>

                <div class="foto-name">{{ $user->namaLengkap() }}</div>
                <div class="foto-role">Siswa PKL</div>

                @if($siswa?->jurusan)
                <div class="foto-jurusan">{{ $siswa->jurusan }} · {{ $siswa->kelas }}</div>
                @endif

                <div class="foto-nis">
                    <span class="foto-nis-label">NIS:</span>
                    <span class="foto-nis-val">{{ $siswa?->nis ?? '—' }}</span>
                </div>
            </div>

            <div style="padding:0 16px 16px">
                <form action="{{ route('siswa.profil.foto') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <input type="file" name="foto_profil" id="foto-input" accept="image/*"
                           style="display:none" onchange="this.form.submit()">
                    <button type="button" onclick="document.getElementById('foto-input').click()"
                            class="btn-secondary" style="width:100%;justify-content:center">
                        📷 Ganti Foto
                    </button>
                </form>
            </div>
        </div>

        {{-- Kartu Ganti Password --}}
        <div class="card">
            <div class="card-header">
                <div class="pass-card-title">🔒 Ganti Password</div>
            </div>
            <div class="card-body">
                <form action="{{ route('siswa.profil.password') }}" method="POST">
                    @csrf @method('PUT')

                    <div class="form-group" style="margin-bottom:12px">
                        <label class="form-label">Password Lama</label>
                        <input type="password" name="password_lama"
                               class="form-control {{ $errors->has('password_lama') ? 'is-invalid' : '' }}"
                               placeholder="••••••••" required>
                        @error('password_lama')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="form-group" style="margin-bottom:12px">
                        <label class="form-label">Password Baru</label>
                        <input type="password" name="password_baru"
                               class="form-control"
                               placeholder="Min 8 karakter" required>
                    </div>

                    <div class="form-group" style="margin-bottom:16px">
                        <label class="form-label">Konfirmasi Password</label>
                        <input type="password" name="password_baru_confirmation"
                               class="form-control"
                               placeholder="Ulangi password baru" required>
                    </div>

                    <button type="submit" class="btn-primary" style="width:100%;justify-content:center">
                        Simpan Password
                    </button>
                </form>
            </div>
        </div>
    </div>

    {{-- ── KOLOM KANAN: Form Data Diri ── --}}
    <div class="card">
        <div class="card-header">
            <div class="card-title-sm">📝 Data Diri</div>
        </div>
        <div class="card-body">
            <form action="{{ route('siswa.profil.update') }}" method="POST">
                @csrf @method('PUT')

                {{-- AKUN --}}
                <div class="form-section-label">Akun</div>
                <div class="form-grid-2">
                    <div class="form-group">
                        <label class="form-label">Nama Depan <span>*</span></label>
                        <input type="text" name="nama_depan"
                               class="form-control {{ $errors->has('nama_depan') ? 'is-invalid' : '' }}"
                               value="{{ old('nama_depan', $user->nama_depan) }}" required>
                        @error('nama_depan')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label class="form-label">Nama Belakang <span>*</span></label>
                        <input type="text" name="nama_belakang"
                               class="form-control {{ $errors->has('nama_belakang') ? 'is-invalid' : '' }}"
                               value="{{ old('nama_belakang', $user->nama_belakang) }}" required>
                        @error('nama_belakang')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="form-group col-full">
                        <label class="form-label">Email <span>*</span></label>
                        <input type="email" name="email"
                               class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                               value="{{ old('email', $user->email) }}" required>
                        @error('email')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                {{-- INFO SEKOLAH --}}
                <div class="form-section-label">Info Sekolah</div>
                <div class="form-grid-3">
                    <div class="form-group">
                        <label class="form-label">NIS</label>
                        <input type="text" class="form-control"
                               value="{{ $siswa?->nis ?? '—' }}" disabled>
                        <div class="form-hint">Diatur oleh admin</div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Kelas</label>
                        <input type="text" name="kelas" class="form-control"
                               value="{{ old('kelas', $siswa?->kelas) }}" placeholder="XII RPL 1">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Jurusan</label>
                        <input type="text" name="jurusan" class="form-control"
                               value="{{ old('jurusan', $siswa?->jurusan) }}" placeholder="Rekayasa Perangkat Lunak">
                    </div>
                </div>

                {{-- DATA PRIBADI --}}
                <div class="form-section-label">Data Pribadi</div>
                <div class="form-grid-2">
                    <div class="form-group">
                        <label class="form-label">Jenis Kelamin</label>
                        <select name="jenis_kelamin" class="form-control">
                            <option value="">-- Pilih --</option>
                            <option value="Laki-laki" {{ old('jenis_kelamin', $siswa?->jenis_kelamin) === 'Laki-laki' ? 'selected' : '' }}>Laki-laki</option>
                            <option value="Perempuan" {{ old('jenis_kelamin', $siswa?->jenis_kelamin) === 'Perempuan' ? 'selected' : '' }}>Perempuan</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Agama</label>
                        <input type="text" name="agama" class="form-control"
                               value="{{ old('agama', $siswa?->agama) }}" placeholder="Islam">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tempat Lahir</label>
                        <input type="text" name="tempat_lahir" class="form-control"
                               value="{{ old('tempat_lahir', $siswa?->tempat_lahir) }}" placeholder="Bandung">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tanggal Lahir</label>
                        <input type="date" name="tanggal_lahir" class="form-control"
                               value="{{ old('tanggal_lahir', $siswa?->tanggal_lahir?->format('Y-m-d')) }}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">No. HP</label>
                        <input type="text" name="no_hp" class="form-control"
                               value="{{ old('no_hp', $siswa?->no_hp) }}" placeholder="08xxxxxxxxxx">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Golongan Darah</label>
                        <select name="golongan_darah" class="form-control">
                            <option value="">-- Pilih --</option>
                            @foreach(['A','B','AB','O'] as $gd)
                            <option value="{{ $gd }}" {{ old('golongan_darah', $siswa?->golongan_darah) === $gd ? 'selected' : '' }}>{{ $gd }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group col-full">
                        <label class="form-label">Alamat Lengkap</label>
                        <textarea name="alamat" rows="3" class="form-control"
                                  placeholder="Jl. Contoh No. 1, Kelurahan...">{{ old('alamat', $siswa?->alamat) }}</textarea>
                    </div>
                </div>

                <div class="form-footer">
                    <button type="reset" class="btn-secondary">Reset</button>
                    <button type="submit" class="btn-primary">💾 Simpan Profil</button>
                </div>

            </form>
        </div>
    </div>

</div>
@endsection