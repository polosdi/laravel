<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        // Bersihkan semua tabel (urutan dari yang paling banyak FK)
        DB::table('log_aktivitas')->truncate();
        DB::table('nilai_pkl')->truncate();
        DB::table('laporan_pkl')->truncate();
        DB::table('jurnal_harian')->truncate();
        DB::table('absensi')->truncate();
        DB::table('pkl_anggota')->truncate();
        DB::table('pkl_pengajuan')->truncate();
        DB::table('profil_guru')->truncate();
        DB::table('profil_siswa')->truncate();
        DB::table('mitra_industri')->truncate();
        DB::table('walikelas')->truncate();
        DB::table('users')->truncate();

        DB::statement('SET FOREIGN_KEY_CHECKS=1;');

        // ── 1. USERS ──────────────────────────────────────────────
        $users = [
            // Admin
            ['nama_depan' => 'Admin',   'nama_belakang' => 'SIMPKL',    'email' => 'admin@simpkl.sch.id',       'role' => 'admin'],
            // Wakasek
            ['nama_depan' => 'Drs.',    'nama_belakang' => 'Hendra Gunawan', 'email' => 'wakasek@simpkl.sch.id', 'role' => 'wakasek'],
            // Pembimbing
            ['nama_depan' => 'Budi',    'nama_belakang' => 'Santoso S.Kom',  'email' => 'budi@simpkl.sch.id',   'role' => 'pembimbing'],
            ['nama_depan' => 'Sari',    'nama_belakang' => 'Dewi M.Pd',      'email' => 'sari@simpkl.sch.id',   'role' => 'pembimbing'],
            // Siswa
            ['nama_depan' => 'Ahmad',   'nama_belakang' => 'Fauzi',          'email' => 'ahmad@siswa.sch.id',   'role' => 'siswa'],
            ['nama_depan' => 'Siti',    'nama_belakang' => 'Nurhaliza',      'email' => 'siti@siswa.sch.id',    'role' => 'siswa'],
            ['nama_depan' => 'Rizky',   'nama_belakang' => 'Pratama',        'email' => 'rizky@siswa.sch.id',   'role' => 'siswa'],
            ['nama_depan' => 'Putri',   'nama_belakang' => 'Rahayu',         'email' => 'putri@siswa.sch.id',   'role' => 'siswa'],
        ];

        $userIds = [];
        foreach ($users as $u) {
            $id = DB::table('users')->insertGetId([
                'nama_depan'   => $u['nama_depan'],
                'nama_belakang'=> $u['nama_belakang'],
                'email'        => $u['email'],
                'password'     => Hash::make('password123'),
                'role'         => $u['role'],
                'created_at'   => now(),
            ]);
            $userIds[$u['email']] = $id;
        }

        $siswaIds = [
            $userIds['ahmad@siswa.sch.id'],
            $userIds['siti@siswa.sch.id'],
            $userIds['rizky@siswa.sch.id'],
            $userIds['putri@siswa.sch.id'],
        ];

        $pembimbingId1 = $userIds['budi@simpkl.sch.id'];
        $pembimbingId2 = $userIds['sari@simpkl.sch.id'];

        // ── 2. PROFIL GURU (untuk pembimbing) ────────────────────
        DB::table('profil_guru')->insert([
            ['user_id' => $pembimbingId1, 'nip' => '198501012010011001', 'jabatan' => 'Guru Produktif', 'jabatan_terakhir' => 'Koordinator PKL', 'tempat_lahir' => 'Bandung', 'tanggal_lahir' => '1985-01-01', 'alamat' => 'Jl. Merdeka No. 10, Bandung', 'no_hp' => '081234567890'],
            ['user_id' => $pembimbingId2, 'nip' => '199003152012012002', 'jabatan' => 'Guru Pembimbing', 'jabatan_terakhir' => 'Wali Kelas XII', 'tempat_lahir' => 'Jakarta',  'tanggal_lahir' => '1990-03-15', 'alamat' => 'Jl. Sudirman No. 5, Jakarta',   'no_hp' => '082345678901'],
        ]);

        // ── 3. PROFIL SISWA ───────────────────────────────────────
        $profilSiswa = [
            [$siswaIds[0], '0012345678', 'XII RPL 1', 'Rekayasa Perangkat Lunak', '081122334455', 'Laki-laki',  'Islam',   'Bandung',  '2006-03-12', 'Jl. Anggrek No. 7, Bandung', 'A'],
            [$siswaIds[1], '0012345679', 'XII RPL 1', 'Rekayasa Perangkat Lunak', '082233445566', 'Perempuan', 'Islam',   'Cimahi',   '2006-07-22', 'Jl. Mawar No. 3, Cimahi',   'B'],
            [$siswaIds[2], '0012345680', 'XII RPL 2', 'Rekayasa Perangkat Lunak', '083344556677', 'Laki-laki',  'Islam',   'Sumedang', '2006-11-05', 'Jl. Melati No. 15, Sumedang','O'],
            [$siswaIds[3], '0012345681', 'XII RPL 2', 'Rekayasa Perangkat Lunak', '084455667788', 'Perempuan', 'Kristen', 'Garut',    '2006-01-30', 'Jl. Dahlia No. 2, Garut',   'AB'],
        ];

        foreach ($profilSiswa as [$uid, $nis, $kelas, $jurusan, $hp, $jk, $agama, $tmpLahir, $tglLahir, $alamat, $gd]) {
            DB::table('profil_siswa')->insert([
                'user_id' => $uid, 'nis' => $nis, 'kelas' => $kelas,
                'jurusan' => $jurusan, 'no_hp' => $hp,
                'jenis_kelamin' => $jk, 'agama' => $agama,
                'tempat_lahir' => $tmpLahir, 'tanggal_lahir' => $tglLahir,
                'alamat' => $alamat, 'golongan_darah' => $gd,
            ]);
        }

        // ── 4. MITRA INDUSTRI ─────────────────────────────────────
        $mitraIds = [];
        $mitras = [
            ['PT Teknologi Nusantara',  'Jl. Asia Afrika No. 12, Bandung',         'https://teknologi-nusantara.co.id'],
            ['CV Kreasi Digital',       'Jl. Dago No. 88, Bandung',                'https://kreasidigital.id'],
            ['PT Solusi Inovasi',       'Jl. Braga No. 45, Bandung',               'https://solusiinovasi.com'],
        ];
        foreach ($mitras as [$nama, $alamat, $web]) {
            $mitraIds[] = DB::table('mitra_industri')->insertGetId([
                'nama_perusahaan'   => $nama,
                'alamat_perusahaan' => $alamat,
                'website'           => $web,
                'created_at'        => now(),
            ]);
        }

        // ── 5. WALIKELAS ──────────────────────────────────────────
        DB::table('walikelas')->insert([
            ['Nama_wakel' => 'Dra. Hj. Fatimah',    'Alamat' => 'Jl. Cihampelas No. 10, Bandung', 'Agama_wakel' => 'Islam',   'No_kontak' => '081122334400', 'Mewalikelaskan' => 1],
            ['Nama_wakel' => 'Bpk. Yusuf S.Pd',     'Alamat' => 'Jl. Diponegoro No. 5, Bandung',  'Agama_wakel' => 'Islam',   'No_kontak' => '082233445500', 'Mewalikelaskan' => 2],
        ]);

        // ── 6. PKL PENGAJUAN ──────────────────────────────────────
        $tanggalMulai = Carbon::now()->subDays(45);

        // Pengajuan 1: Ahmad & Siti ke PT Teknologi Nusantara (AKTIF)
        $pengajuan1 = DB::table('pkl_pengajuan')->insertGetId([
            'ketua_id'          => $siswaIds[0],
            'nama_perusahaan'   => 'PT Teknologi Nusantara',
            'alamat_perusahaan' => 'Jl. Asia Afrika No. 12, Bandung',
            'website'           => 'https://teknologi-nusantara.co.id',
            'status_pembimbing' => 'disetujui',
            'status_wakasek'    => 'disetujui',
            'pembimbing_id'     => $pembimbingId1,
            'tanggal_pengajuan' => $tanggalMulai,
        ]);

        // Pengajuan 2: Rizky & Putri ke CV Kreasi Digital (pending wakasek)
        $pengajuan2 = DB::table('pkl_pengajuan')->insertGetId([
            'ketua_id'          => $siswaIds[2],
            'nama_perusahaan'   => 'CV Kreasi Digital',
            'alamat_perusahaan' => 'Jl. Dago No. 88, Bandung',
            'website'           => 'https://kreasidigital.id',
            'status_pembimbing' => 'disetujui',
            'status_wakasek'    => 'pending',
            'pembimbing_id'     => $pembimbingId2,
            'tanggal_pengajuan' => Carbon::now()->subDays(5),
        ]);

        // ── 7. PKL ANGGOTA ────────────────────────────────────────
        DB::table('pkl_anggota')->insert([
            ['pengajuan_id' => $pengajuan1, 'siswa_id' => $siswaIds[0], 'status_keanggotaan' => 'aktif'],
            ['pengajuan_id' => $pengajuan1, 'siswa_id' => $siswaIds[1], 'status_keanggotaan' => 'aktif'],
            ['pengajuan_id' => $pengajuan2, 'siswa_id' => $siswaIds[2], 'status_keanggotaan' => 'aktif'],
            ['pengajuan_id' => $pengajuan2, 'siswa_id' => $siswaIds[3], 'status_keanggotaan' => 'aktif'],
        ]);

        // ── 8. ABSENSI (45 hari kerja untuk siswa 0 & 1) ─────────
        $statusAbsensi = ['Hadir', 'Hadir', 'Hadir', 'Hadir', 'Izin', 'Sakit', 'Hadir', 'Hadir', 'Hadir', 'Alpa'];

        for ($i = 0; $i < 45; $i++) {
            $tgl = Carbon::now()->subDays(44 - $i);
            if ($tgl->isWeekend()) continue;

            foreach ([$siswaIds[0], $siswaIds[1]] as $sId) {
                $status = $statusAbsensi[array_rand($statusAbsensi)];
                $hadir  = $status === 'Hadir';
                DB::table('absensi')->insert([
                    'siswa_id'   => $sId,
                    'tanggal'    => $tgl->format('Y-m-d'),
                    'jam_masuk'  => $hadir ? '07:30:00' : null,
                    'jam_pulang' => $hadir ? '16:00:00' : null,
                    'status'     => $status,
                    'keterangan' => !$hadir ? 'Keterangan ' . strtolower($status) : null,
                ]);
            }
        }

        // ── 9. JURNAL HARIAN ──────────────────────────────────────
        $kegiatanSamples = [
            'Mempelajari struktur database dan relasi antar tabel yang digunakan sistem.',
            'Membuat desain UI untuk halaman dashboard menggunakan Figma.',
            'Mengimplementasikan API endpoint untuk fitur autentikasi pengguna.',
            'Melakukan testing dan debugging pada modul laporan mingguan.',
            'Mengikuti daily standup meeting dan code review bersama tim senior.',
            'Membuat dokumentasi teknis untuk fitur yang sudah selesai dibangun.',
            'Belajar dan praktek penggunaan Git untuk version control.',
            'Mengerjakan fitur CRUD data siswa sesuai spesifikasi yang diberikan.',
            'Presentasi progress pekerjaan kepada pembimbing lapangan.',
            'Melakukan optimasi query database dan memperbaiki performa aplikasi.',
        ];

        $statusValidasi = ['pending', 'valid', 'valid', 'valid', 'tolak'];

        for ($i = 0; $i < 30; $i++) {
            $tgl = Carbon::now()->subDays(29 - $i);
            if ($tgl->isWeekend()) continue;

            foreach ([$siswaIds[0], $siswaIds[1]] as $sId) {
                DB::table('jurnal_harian')->insert([
                    'siswa_id'           => $sId,
                    'tanggal'            => $tgl->format('Y-m-d'),
                    'jam_masuk'          => '07:30:00',
                    'jam_keluar'         => '16:00:00',
                    'kegiatan'           => $kegiatanSamples[array_rand($kegiatanSamples)],
                    'status_validasi'    => $i >= 27 ? 'pending' : $statusValidasi[array_rand($statusValidasi)],
                    'komentar_pembimbing'=> $i < 27 ? 'Baik, pertahankan semangat belajarnya!' : null,
                ]);
            }
        }

        // ── 10. LAPORAN PKL ───────────────────────────────────────
        foreach ([$siswaIds[0], $siswaIds[1]] as $sId) {
            // Laporan mingguan
            for ($w = 1; $w <= 6; $w++) {
                DB::table('laporan_pkl')->insert([
                    'siswa_id'          => $sId,
                    'judul_laporan'     => "Laporan Mingguan Ke-{$w}",
                    'jenis_laporan'     => 'mingguan',
                    'status_pembimbing' => $w <= 5 ? 'disetujui' : 'pending',
                    'status_wakasek'    => $w <= 4 ? 'disetujui' : 'pending',
                    'tampil_di_publik'  => $w <= 4,
                    'created_at'        => Carbon::now()->subDays((6 - $w) * 7),
                ]);
            }
            // Laporan akhir (draft)
            DB::table('laporan_pkl')->insert([
                'siswa_id'          => $sId,
                'judul_laporan'     => 'Laporan Akhir PKL',
                'jenis_laporan'     => 'akhir',
                'status_pembimbing' => 'pending',
                'status_wakasek'    => 'pending',
                'tampil_di_publik'  => false,
                'created_at'        => now(),
            ]);
        }

        // ── 11. NILAI PKL (untuk Ahmad & Siti yang sudah selesai) ─
        DB::table('nilai_pkl')->insert([
            [
                'siswa_id'           => $siswaIds[0],
                'pembimbing_id'      => $pembimbingId1,
                'nilai_sikap'        => 88,
                'nilai_keterampilan' => 92,
                'nilai_laporan'      => 85,
                'nilai_akhir'        => round((88 + 92 + 85) / 3, 2),
                'predikat'           => 'B',
                'catatan'            => 'Ahmad menunjukkan perkembangan yang sangat baik. Disiplin, kreatif, dan mampu bekerja dalam tim.',
                'created_at'         => now()->subDays(2),
            ],
            [
                'siswa_id'           => $siswaIds[1],
                'pembimbing_id'      => $pembimbingId1,
                'nilai_sikap'        => 90,
                'nilai_keterampilan' => 87,
                'nilai_laporan'      => 93,
                'nilai_akhir'        => round((90 + 87 + 93) / 3, 2),
                'predikat'           => 'A',
                'catatan'            => 'Siti sangat teliti dan laporan yang dibuat sangat berkualitas. Pertahankan!',
                'created_at'         => now()->subDays(2),
            ],
        ]);

        // ── 12. LOG AKTIVITAS ─────────────────────────────────────
        $logs = [
            [$siswaIds[0], 'Login ke sistem sebagai siswa',           now()->subDays(1)],
            [$siswaIds[0], 'Menambahkan jurnal harian tanggal hari ini', now()->subHours(2)],
            [$siswaIds[0], 'Memperbarui data profil',                  now()->subHours(5)],
            [$siswaIds[0], 'Mengunggah laporan PKL: Laporan Mingguan Ke-6', now()->subDay()],
            [$siswaIds[1], 'Login ke sistem sebagai siswa',            now()->subHours(3)],
            [$siswaIds[1], 'Menambahkan jurnal harian tanggal hari ini', now()->subHours(3)],
            [$pembimbingId1, 'Login ke sistem sebagai pembimbing',     now()->subHours(1)],
        ];

        foreach ($logs as [$uid, $aktivitas, $waktu]) {
            DB::table('log_aktivitas')->insert([
                'id_users'  => $uid,
                'aktivitas' => $aktivitas,
                'waktu'     => $waktu,
            ]);
        }

        $this->command->info('✅ Seeder selesai! Akun tersedia:');
        $this->command->table(
            ['Role', 'Email', 'Password'],
            [
                ['Admin',      'admin@simpkl.sch.id',   'password123'],
                ['Wakasek',    'wakasek@simpkl.sch.id', 'password123'],
                ['Pembimbing', 'budi@simpkl.sch.id',    'password123'],
                ['Pembimbing', 'sari@simpkl.sch.id',    'password123'],
                ['Siswa',      'ahmad@siswa.sch.id',    'password123'],
                ['Siswa',      'siti@siswa.sch.id',     'password123'],
                ['Siswa',      'rizky@siswa.sch.id',    'password123'],
                ['Siswa',      'putri@siswa.sch.id',    'password123'],
            ]
        );
    }
}
