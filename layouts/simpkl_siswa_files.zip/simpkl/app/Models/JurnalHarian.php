<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class JurnalHarian extends Model
{
    public $timestamps = false;

    protected $table = 'jurnal_harian';

    protected $fillable = [
        'siswa_id',
        'tanggal',
        'jam_masuk',
        'jam_keluar',
        'kegiatan',
        'foto_kegiatan',
        'status_validasi',
        'komentar_pembimbing',
    ];

    protected $casts = [
        'tanggal' => 'date',
    ];

    // ─── RELASI ───

    public function siswa(): BelongsTo
    {
        return $this->belongsTo(User::class, 'siswa_id');
    }

    // ─── SCOPE ───

    public function scopePending($query)
    {
        return $query->where('status_validasi', 'pending');
    }

    public function scopeValid($query)
    {
        return $query->where('status_validasi', 'valid');
    }

    public function scopeOlehSiswa($query, int $siswaId)
    {
        return $query->where('siswa_id', $siswaId);
    }

    // ─── HELPER ───

    public function jamMasukFormatted(): string
    {
        return $this->jam_masuk ? substr($this->jam_masuk, 0, 5) : '—';
    }

    public function jamKeluarFormatted(): string
    {
        return $this->jam_keluar ? substr($this->jam_keluar, 0, 5) : '—';
    }

    public function badgeClass(): string
    {
        return match($this->status_validasi) {
            'valid'  => 'badge-valid',
            'tolak'  => 'badge-tolak',
            default  => 'badge-pending',
        };
    }
}
