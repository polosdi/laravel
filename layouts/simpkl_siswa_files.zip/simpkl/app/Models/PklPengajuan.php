<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Carbon\Carbon;

class PklPengajuan extends Model
{
    public $timestamps = false;

    protected $table = 'pkl_pengajuan';

    protected $fillable = [
        'ketua_id',
        'nama_perusahaan',
        'alamat_perusahaan',
        'website',
        'file_dokumen',
        'status_pembimbing',
        'status_wakasek',
        'pembimbing_id',
        'tanggal_pengajuan',
    ];

    protected $casts = [
        'tanggal_pengajuan' => 'datetime',
    ];

    // ─── RELASI ───

    public function ketua(): BelongsTo
    {
        return $this->belongsTo(User::class, 'ketua_id');
    }

    public function pembimbing(): BelongsTo
    {
        return $this->belongsTo(User::class, 'pembimbing_id');
    }

    public function anggota(): HasMany
    {
        return $this->hasMany(PklAnggota::class, 'pengajuan_id');
    }

    // ─── HELPER ───

    /**
     * Apakah pengajuan ini sudah disetujui sepenuhnya
     */
    public function isAktif(): bool
    {
        return $this->status_pembimbing === 'disetujui'
            && $this->status_wakasek === 'disetujui';
    }

    /**
     * Hitung estimasi sisa hari PKL (asumsi 90 hari dari tanggal_pengajuan)
     */
    public function sisiHari(int $durasiHari = 90): int
    {
        if (!$this->tanggal_pengajuan) return 0;
        $selesai = Carbon::parse($this->tanggal_pengajuan)->addDays($durasiHari);
        return max(0, (int) now()->diffInDays($selesai, false));
    }

    /**
     * Hitung persen kemajuan PKL (0-100)
     */
    public function persenKemajuan(int $durasiHari = 90): int
    {
        if (!$this->tanggal_pengajuan) return 0;
        $mulai = Carbon::parse($this->tanggal_pengajuan);
        $sudahBerjalan = $mulai->diffInDays(now());
        return min(100, (int) round($sudahBerjalan / $durasiHari * 100));
    }
}
