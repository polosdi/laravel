<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Walikelas extends Model
{
    public $timestamps = false;

    protected $table    = 'walikelas';
    protected $primaryKey = 'id_walikelas';

    protected $fillable = [
        'Nama_wakel',
        'Alamat',
        'Agama_wakel',
        'No_kontak',
        'Mewalikelaskan',
    ];
}
