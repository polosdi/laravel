<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class NilaiPkl extends Model
{
    public $timestamps = false;
    const CREATED_AT = 'created_at';
    const UPDATED_AT = null;

    protected $table = 'nilai_pkl';

    protected $fillable = [
        'siswa_id',
        'pembimbing_id',
        'nilai_sikap',
        'nilai_keterampilan',
        'nilai_laporan',
        'nilai_akhir',
        'predikat',
        'catatan',
    ];

    protected $casts = [
        'nilai_akhir' => 'decimal:2',
        'created_at'  => 'datetime',
    ];

    // ─── RELASI ───

    public function siswa(): BelongsTo
    {
        return $this->belongsTo(User::class, 'siswa_id');
    }

    public function pembimbing(): BelongsTo
    {
        return $this->belongsTo(User::class, 'pembimbing_id');
    }

    // ─── HELPER ───

    /**
     * Hitung nilai akhir otomatis dan predikat berdasarkan 3 komponen (bobot sama)
     * Bisa dipanggil sebelum save jika ingin auto-hitung
     */
    public function hitungNilaiAkhir(): self
    {
        $this->nilai_akhir = round(
            ($this->nilai_sikap + $this->nilai_keterampilan + $this->nilai_laporan) / 3,
            2
        );
        $this->predikat = $this->tentukanPredikat($this->nilai_akhir);
        return $this;
    }

    public static function tentukanPredikat(float $nilai): string
    {
        return match(true) {
            $nilai >= 90 => 'A',
            $nilai >= 80 => 'B',
            $nilai >= 70 => 'C',
            $nilai >= 60 => 'D',
            default      => 'E',
        };
    }
}
