<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PklAnggota extends Model
{
    public $timestamps = false;

    protected $table = 'pkl_anggota';

    protected $fillable = [
        'pengajuan_id',
        'siswa_id',
        'status_keanggotaan',
    ];

    public function pengajuan(): BelongsTo
    {
        return $this->belongsTo(PklPengajuan::class, 'pengajuan_id');
    }

    public function siswa(): BelongsTo
    {
        return $this->belongsTo(User::class, 'siswa_id');
    }
}
