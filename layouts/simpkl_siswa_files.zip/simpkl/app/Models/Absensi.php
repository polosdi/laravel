<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Absensi extends Model
{
    public $timestamps = false;

    protected $table = 'absensi';

    protected $fillable = [
        'siswa_id',
        'tanggal',
        'jam_masuk',
        'jam_pulang',
        'status',
        'keterangan',
    ];

    protected $casts = [
        'tanggal' => 'date',
    ];

    // ─── RELASI ───

    public function siswa(): BelongsTo
    {
        return $this->belongsTo(User::class, 'siswa_id');
    }

    // ─── SCOPE ───

    public function scopeOlehSiswa($query, int $siswaId)
    {
        return $query->where('siswa_id', $siswaId);
    }

    public function scopeHadir($query)
    {
        return $query->where('status', 'Hadir');
    }

    // ─── HELPER ───

    public function badgeClass(): string
    {
        return 'badge-' . strtolower($this->status);
    }

    public function jamMasukFormatted(): string
    {
        return $this->jam_masuk ? substr($this->jam_masuk, 0, 5) : '—';
    }

    public function jamPulangFormatted(): string
    {
        return $this->jam_pulang ? substr($this->jam_pulang, 0, 5) : '—';
    }
}
