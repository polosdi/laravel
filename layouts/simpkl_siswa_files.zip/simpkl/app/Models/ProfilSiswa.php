<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProfilSiswa extends Model
{
    public $timestamps = false;

    protected $table = 'profil_siswa';

    protected $fillable = [
        'user_id',
        'nis',
        'kelas',
        'jurusan',
        'no_hp',
        'foto_profil',
        'jenis_kelamin',
        'agama',
        'tempat_lahir',
        'tanggal_lahir',
        'alamat',
        'golongan_darah',
    ];

    protected $casts = [
        'tanggal_lahir' => 'date',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function fotoUrl(): string
    {
        return $this->foto_profil
            ? asset('storage/' . $this->foto_profil)
            : asset('images/default-avatar.png');
    }
}
