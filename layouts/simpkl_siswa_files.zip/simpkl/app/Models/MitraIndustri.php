<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MitraIndustri extends Model
{
    public $timestamps = false;
    const CREATED_AT = 'created_at';
    const UPDATED_AT = null;

    protected $table = 'mitra_industri';

    protected $fillable = [
        'nama_perusahaan',
        'alamat_perusahaan',
        'website',
        'logo',
    ];

    public function logoUrl(): string
    {
        return $this->logo
            ? asset('storage/' . $this->logo)
            : asset('images/default-company.png');
    }
}
