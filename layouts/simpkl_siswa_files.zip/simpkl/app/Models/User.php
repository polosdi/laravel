<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasMany;

class User extends Authenticatable
{
    protected $fillable = [
        'nama_depan',
        'nama_belakang',
        'email',
        'password',
        'role',
    ];

    protected $hidden = ['password'];

    // Tidak ada updated_at di migrasi
    public $timestamps = false;
    const CREATED_AT = 'created_at';
    const UPDATED_AT = null;

    // ─── RELASI ───

    public function profilSiswa(): HasOne
    {
        return $this->hasOne(ProfilSiswa::class, 'user_id');
    }

    public function profilGuru(): HasOne
    {
        return $this->hasOne(ProfilGuru::class, 'user_id');
    }

    public function jurnalHarian(): HasMany
    {
        return $this->hasMany(JurnalHarian::class, 'siswa_id');
    }

    public function absensi(): HasMany
    {
        return $this->hasMany(Absensi::class, 'siswa_id');
    }

    public function laporanPkl(): HasMany
    {
        return $this->hasMany(LaporanPkl::class, 'siswa_id');
    }

    public function nilaiPkl(): HasMany
    {
        return $this->hasMany(NilaiPkl::class, 'siswa_id');
    }

    public function pklAnggota(): HasMany
    {
        return $this->hasMany(PklAnggota::class, 'siswa_id');
    }

    public function logAktivitas(): HasMany
    {
        return $this->hasMany(LogAktivitas::class, 'id_users');
    }

    // ─── HELPER ───

    public function namaLengkap(): string
    {
        return trim("{$this->nama_depan} {$this->nama_belakang}");
    }

    public function inisial(): string
    {
        $d = strtoupper(substr($this->nama_depan ?? '', 0, 1));
        $b = strtoupper(substr($this->nama_belakang ?? '', 0, 1));
        return $d . $b;
    }

    public function isSiswa(): bool   { return $this->role === 'siswa'; }
    public function isPembimbing(): bool { return $this->role === 'pembimbing'; }
    public function isWakasek(): bool { return $this->role === 'wakasek'; }
    public function isAdmin(): bool   { return $this->role === 'admin'; }
}
