<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Auth;

class LogAktivitas extends Model
{
    public $timestamps = false;

    protected $table    = 'log_aktivitas';
    protected $primaryKey = 'id_log';

    protected $fillable = [
        'id_users',
        'aktivitas',
        'waktu',
    ];

    protected $casts = [
        'waktu' => 'datetime',
    ];

    // ─── RELASI ───

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'id_users');
    }

    // ─── HELPER STATIS ───

    /**
     * Catat aktivitas untuk user yang sedang login.
     * Penggunaan: LogAktivitas::catat('Menambah jurnal harian');
     */
    public static function catat(string $aktivitas, ?int $userId = null): self
    {
        return self::create([
            'id_users'  => $userId ?? Auth::id(),
            'aktivitas' => $aktivitas,
            'waktu'     => now(),
        ]);
    }
}
