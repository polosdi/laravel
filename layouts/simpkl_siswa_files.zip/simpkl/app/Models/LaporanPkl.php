<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class LaporanPkl extends Model
{
    public $timestamps = false;
    const CREATED_AT = 'created_at';
    const UPDATED_AT = null;

    protected $table = 'laporan_pkl';

    protected $fillable = [
        'siswa_id',
        'judul_laporan',
        'file_path',
        'jenis_laporan',
        'status_pembimbing',
        'status_wakasek',
        'catatan_revisi',
        'tampil_di_publik',
    ];

    protected $casts = [
        'tampil_di_publik' => 'boolean',
        'created_at'       => 'datetime',
    ];

    // ─── RELASI ───

    public function siswa(): BelongsTo
    {
        return $this->belongsTo(User::class, 'siswa_id');
    }

    // ─── SCOPE ───

    public function scopeOlehSiswa($query, int $siswaId)
    {
        return $query->where('siswa_id', $siswaId);
    }

    public function scopeDisetujui($query)
    {
        return $query->where('status_pembimbing', 'disetujui');
    }

    // ─── HELPER ───

    public function judul(): string
    {
        return $this->judul_laporan ?? ('Laporan ' . ucfirst($this->jenis_laporan));
    }

    public function icon(): string
    {
        return $this->jenis_laporan === 'akhir' ? '📋' : '📝';
    }

    public function fileUrl(): ?string
    {
        return $this->file_path ? asset('storage/' . $this->file_path) : null;
    }
}
