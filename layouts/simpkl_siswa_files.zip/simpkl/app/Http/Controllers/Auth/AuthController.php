<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\LogAktivitas;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    // ── Tampilkan form login ──────────────────────────────────────
    public function showLogin()
    {
        if (Auth::check()) {
            return $this->redirectByRole(Auth::user()->role);
        }
        return view('auth.login');
    }

    // ── Proses login ─────────────────────────────────────────────
    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email'    => ['required', 'email'],
            'password' => ['required'],
        ]);

        if (!Auth::attempt($credentials, $request->boolean('remember'))) {
            throw ValidationException::withMessages([
                'email' => 'Email atau password salah.',
            ]);
        }

        $request->session()->regenerate();

        $user = Auth::user();

        LogAktivitas::catat("Login ke sistem sebagai {$user->role}", $user->id);

        return $this->redirectByRole($user->role);
    }

    // ── Logout ───────────────────────────────────────────────────
    public function logout(Request $request)
    {
        LogAktivitas::catat('Logout dari sistem');

        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login')->with('success', 'Berhasil keluar.');
    }

    // ── Redirect berdasarkan role ─────────────────────────────────
    private function redirectByRole(string $role)
    {
        return match($role) {
            'siswa'       => redirect()->route('siswa.dashboard'),
            'pembimbing'  => redirect()->route('pembimbing.dashboard'),
            'wakasek'     => redirect()->route('wakasek.dashboard'),
            'admin'       => redirect()->route('admin.dashboard'),
            default       => redirect('/'),
        };
    }
}
