<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MitraIndustri;
use App\Models\LogAktivitas;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class MitraIndustriController extends Controller
{
    public function index(Request $request)
    {
        $query = MitraIndustri::query();

        if ($request->filled('search')) {
            $query->where('nama_perusahaan', 'like', '%'.$request->search.'%');
        }

        $mitras = $query->orderByDesc('created_at')->paginate(12)->withQueryString();

        return view('admin.mitra.index', compact('mitras'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama_perusahaan'  => 'required|string|max:100',
            'alamat_perusahaan'=> 'nullable|string',
            'website'          => 'nullable|url|max:100',
            'logo'             => 'nullable|image|max:2048',
        ]);

        if ($request->hasFile('logo')) {
            $validated['logo'] = $request->file('logo')->store('mitra/logo', 'public');
        }

        $mitra = MitraIndustri::create($validated);
        LogAktivitas::catat("Admin menambah mitra industri: {$mitra->nama_perusahaan}");

        return redirect()->route('admin.mitra.index')
            ->with('success', 'Mitra industri berhasil ditambahkan.');
    }

    public function update(Request $request, MitraIndustri $mitra)
    {
        $validated = $request->validate([
            'nama_perusahaan'  => 'required|string|max:100',
            'alamat_perusahaan'=> 'nullable|string',
            'website'          => 'nullable|url|max:100',
            'logo'             => 'nullable|image|max:2048',
        ]);

        if ($request->hasFile('logo')) {
            if ($mitra->logo) Storage::disk('public')->delete($mitra->logo);
            $validated['logo'] = $request->file('logo')->store('mitra/logo', 'public');
        }

        $mitra->update($validated);
        LogAktivitas::catat("Admin memperbarui mitra: {$mitra->nama_perusahaan}");

        return redirect()->route('admin.mitra.index')
            ->with('success', 'Mitra berhasil diperbarui.');
    }

    public function destroy(MitraIndustri $mitra)
    {
        if ($mitra->logo) Storage::disk('public')->delete($mitra->logo);
        $nama = $mitra->nama_perusahaan;
        $mitra->delete();
        LogAktivitas::catat("Admin menghapus mitra: {$nama}");

        return redirect()->route('admin.mitra.index')
            ->with('success', 'Mitra berhasil dihapus.');
    }
}
