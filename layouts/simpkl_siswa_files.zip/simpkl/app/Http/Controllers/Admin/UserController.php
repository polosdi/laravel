<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\ProfilSiswa;
use App\Models\ProfilGuru;
use App\Models\LogAktivitas;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $query = User::query();

        if ($request->filled('role')) {
            $query->where('role', $request->role);
        }

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('nama_depan', 'like', "%{$search}%")
                  ->orWhere('nama_belakang', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%");
            });
        }

        $users = $query->orderByDesc('created_at')->paginate(15)->withQueryString();

        return view('admin.users.index', compact('users'));
    }

    public function create()
    {
        return view('admin.users.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama_depan'  => 'required|string|max:50',
            'nama_belakang' => 'required|string|max:50',
            'email'       => 'required|email|unique:users,email',
            'password'    => 'required|min:8|confirmed',
            'role'        => 'required|in:siswa,pembimbing,wakasek,admin',
        ]);

        $user = User::create([
            'nama_depan'   => $validated['nama_depan'],
            'nama_belakang' => $validated['nama_belakang'],
            'email'        => $validated['email'],
            'password'     => Hash::make($validated['password']),
            'role'         => $validated['role'],
        ]);

        // Buat profil kosong otomatis
        if ($user->role === 'siswa') {
            ProfilSiswa::create(['user_id' => $user->id]);
        } elseif (in_array($user->role, ['pembimbing', 'wakasek', 'admin'])) {
            ProfilGuru::create(['user_id' => $user->id]);
        }

        LogAktivitas::catat("Admin membuat user baru: {$user->namaLengkap()} ({$user->role})");

        return redirect()->route('admin.users.index')
            ->with('success', "User {$user->namaLengkap()} berhasil dibuat.");
    }

    public function show(User $user)
    {
        $user->load('profilSiswa', 'profilGuru');
        return view('admin.users.show', compact('user'));
    }

    public function edit(User $user)
    {
        return view('admin.users.edit', compact('user'));
    }

    public function update(Request $request, User $user)
    {
        $validated = $request->validate([
            'nama_depan'   => 'required|string|max:50',
            'nama_belakang'=> 'required|string|max:50',
            'email'        => ['required', 'email', Rule::unique('users')->ignore($user->id)],
            'role'         => 'required|in:siswa,pembimbing,wakasek,admin',
            'password'     => 'nullable|min:8|confirmed',
        ]);

        $user->fill([
            'nama_depan'   => $validated['nama_depan'],
            'nama_belakang'=> $validated['nama_belakang'],
            'email'        => $validated['email'],
            'role'         => $validated['role'],
        ]);

        if (!empty($validated['password'])) {
            $user->password = Hash::make($validated['password']);
        }

        $user->save();

        LogAktivitas::catat("Admin memperbarui user: {$user->namaLengkap()}");

        return redirect()->route('admin.users.index')
            ->with('success', 'User berhasil diperbarui.');
    }

    public function destroy(User $user)
    {
        $nama = $user->namaLengkap();
        $user->delete();

        LogAktivitas::catat("Admin menghapus user: {$nama}");

        return redirect()->route('admin.users.index')
            ->with('success', "User {$nama} berhasil dihapus.");
    }
}
