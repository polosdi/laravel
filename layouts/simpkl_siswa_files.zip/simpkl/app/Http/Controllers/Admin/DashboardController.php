<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Absensi;
use App\Models\JurnalHarian;
use App\Models\LaporanPkl;
use App\Models\LogAktivitas;
use App\Models\MitraIndustri;
use App\Models\NilaiPkl;
use App\Models\PklAnggota;
use App\Models\PklPengajuan;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        // ── 1. RINGKASAN USER ─────────────────────────────────────
        $totalSiswa      = User::where('role', 'siswa')->count();
        $totalPembimbing = User::where('role', 'pembimbing')->count();
        $totalWakasek    = User::where('role', 'wakasek')->count();
        $totalAdmin      = User::where('role', 'admin')->count();
        $totalUser       = $totalSiswa + $totalPembimbing + $totalWakasek + $totalAdmin;

        // ── 2. RINGKASAN PKL ──────────────────────────────────────
        $totalPengajuan      = PklPengajuan::count();
        $pengajuanPending    = PklPengajuan::where('status_wakasek', 'pending')->count();
        $pengajuanDisetujui  = PklPengajuan::where('status_wakasek', 'disetujui')->count();
        $pengajuanDitolak    = PklPengajuan::where('status_wakasek', 'ditolak')->count();
        $siswaAktifPkl       = PklAnggota::where('status_keanggotaan', 'aktif')->count();

        // ── 3. JURNAL & ABSENSI ───────────────────────────────────
        $totalJurnal     = JurnalHarian::count();
        $jurnalPending   = JurnalHarian::where('status_validasi', 'pending')->count();
        $jurnalValid     = JurnalHarian::where('status_validasi', 'valid')->count();
        $totalAbsensi    = Absensi::count();
        $totalHadir      = Absensi::where('status', 'Hadir')->count();
        $rataKehadiran   = $totalAbsensi > 0
            ? round($totalHadir / $totalAbsensi * 100)
            : 0;

        // ── 4. LAPORAN PKL ────────────────────────────────────────
        $totalLaporan        = LaporanPkl::count();
        $laporanPending      = LaporanPkl::where('status_pembimbing', 'pending')->count();
        $laporanDisetujui    = LaporanPkl::where('status_pembimbing', 'disetujui')->count();
        $laporanRevisi       = LaporanPkl::where('status_pembimbing', 'revisi')->count();

        // ── 5. MITRA INDUSTRI ─────────────────────────────────────
        $totalMitra = MitraIndustri::count();

        // ── 6. DISTRIBUSI JURUSAN (dari profil_siswa) ─────────────
        $distribusiJurusan = DB::table('profil_siswa')
            ->select('jurusan', DB::raw('count(*) as total'))
            ->whereNotNull('jurusan')
            ->groupBy('jurusan')
            ->orderByDesc('total')
            ->limit(6)
            ->get();

        // ── 7. SISWA PKL PER MITRA (TOP 5) ───────────────────────
        $mitraPopuler = PklPengajuan::select('nama_perusahaan', DB::raw('count(*) as total'))
            ->where('status_wakasek', 'disetujui')
            ->groupBy('nama_perusahaan')
            ->orderByDesc('total')
            ->limit(5)
            ->get();

        // ── 8. PENGAJUAN PKL TERBARU ──────────────────────────────
        $pengajuanTerbaru = PklPengajuan::with(['ketua', 'pembimbing'])
            ->latest('tanggal_pengajuan')
            ->take(8)
            ->get();

        // ── 9. LOG AKTIVITAS TERBARU ──────────────────────────────
        $logTerbaru = LogAktivitas::with('user')
            ->orderByDesc('waktu')
            ->take(10)
            ->get();

        // ── 10. NILAI RATA-RATA PKL ───────────────────────────────
        $rataRataNilai = NilaiPkl::avg('nilai_akhir');
        $distribusiNilai = NilaiPkl::select('predikat', DB::raw('count(*) as total'))
            ->whereNotNull('predikat')
            ->groupBy('predikat')
            ->orderBy('predikat')
            ->get();

        // ── 11. USER TERBARU ──────────────────────────────────────
        $userTerbaru = User::with('profilSiswa')
            ->where('role', 'siswa')
            ->orderByDesc('created_at')
            ->take(5)
            ->get();

        // ── 12. STATISTIK ABSENSI PER STATUS ─────────────────────
        $absensiPerStatus = Absensi::select('status', DB::raw('count(*) as total'))
            ->groupBy('status')
            ->get()
            ->keyBy('status');

        return view('admin.dashboard', compact(
            // user
            'totalSiswa', 'totalPembimbing', 'totalWakasek', 'totalAdmin', 'totalUser',
            // pkl
            'totalPengajuan', 'pengajuanPending', 'pengajuanDisetujui', 'pengajuanDitolak', 'siswaAktifPkl',
            // jurnal & absensi
            'totalJurnal', 'jurnalPending', 'jurnalValid', 'totalAbsensi', 'rataKehadiran',
            // laporan
            'totalLaporan', 'laporanPending', 'laporanDisetujui', 'laporanRevisi',
            // mitra
            'totalMitra',
            // chart data
            'distribusiJurusan', 'mitraPopuler',
            // tabel
            'pengajuanTerbaru', 'logTerbaru', 'userTerbaru',
            // nilai
            'rataRataNilai', 'distribusiNilai',
            // absensi
            'absensiPerStatus',
        ));
    }
}
