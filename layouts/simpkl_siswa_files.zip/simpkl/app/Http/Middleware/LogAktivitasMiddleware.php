<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\LogAktivitas;
use Symfony\Component\HttpFoundation\Response;

class LogAktivitasMiddleware
{
    /**
     * Method yang tidak perlu di-log (hindari log GET biasa agar tidak terlalu berisik).
     * Log hanya untuk POST/PUT/PATCH/DELETE.
     */
    protected array $loggedMethods = ['POST', 'PUT', 'PATCH', 'DELETE'];

    /**
     * Route name yang dikecualikan dari logging
     */
    protected array $kecualikan = [
        'logout',
        'login',
    ];

    public function handle(Request $request, Closure $next): Response
    {
        $response = $next($request);

        if (
            Auth::check()
            && in_array($request->method(), $this->loggedMethods)
            && !in_array($request->route()?->getName(), $this->kecualikan)
            && $response->isSuccessful()
        ) {
            LogAktivitas::catat(
                $this->buildPesan($request),
                Auth::id()
            );
        }

        return $response;
    }

    private function buildPesan(Request $request): string
    {
        $method = $request->method();
        $path   = $request->path();

        return match($method) {
            'POST'   => "Membuat data baru pada: /{$path}",
            'PUT',
            'PATCH'  => "Memperbarui data pada: /{$path}",
            'DELETE' => "Menghapus data pada: /{$path}",
            default  => "{$method} /{$path}",
        };
    }
}
