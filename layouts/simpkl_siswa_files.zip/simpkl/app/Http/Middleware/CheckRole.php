<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class CheckRole
{
    /**
     * Penggunaan di routes:
     *   Route::middleware(['auth', 'role:siswa'])
     *   Route::middleware(['auth', 'role:siswa,admin'])   ← multi-role
     */
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        if (!Auth::check()) {
            return redirect()->route('login');
        }

        $user = Auth::user();

        // Cek apakah role user ada di daftar yang diizinkan
        if (!in_array($user->role, $roles)) {
            abort(403, 'Akses ditolak. Halaman ini tidak tersedia untuk role Anda.');
        }

        return $next($request);
    }
}
