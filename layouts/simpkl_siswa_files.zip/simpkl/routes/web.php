<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Siswa\DashboardController   as SiswaDashboard;
use App\Http\Controllers\Siswa\ProfilController       as SiswaProfil;
use App\Http\Controllers\Siswa\PklPengajuanController as SiswaPkl;
use App\Http\Controllers\Siswa\JurnalController       as SiswaJurnal;
use App\Http\Controllers\Siswa\AbsensiController      as SiswaAbsensi;
use App\Http\Controllers\Siswa\LaporanController      as SiswaLaporan;
use App\Http\Controllers\Siswa\NilaiController        as SiswaNilai;
use App\Http\Controllers\Siswa\LogAktivitasController as SiswaLog;

// ── PUBLIC ────────────────────────────────────────────────
Route::get('/', fn() => view('index'))->name('home');

Route::middleware('guest')->group(function () {
    Route::get('/login',  [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
});

Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');

// ── SISWA ─────────────────────────────────────────────────
Route::middleware(['auth', 'role:siswa'])->prefix('siswa')->name('siswa.')->group(function () {

    Route::get('/dashboard', [SiswaDashboard::class, 'index'])->name('dashboard');

    Route::get('/profil',          [SiswaProfil::class, 'index'])->name('profil');
    Route::put('/profil',          [SiswaProfil::class, 'update'])->name('profil.update');
    Route::post('/profil/foto',    [SiswaProfil::class, 'uploadFoto'])->name('profil.foto');
    Route::put('/profil/password', [SiswaProfil::class, 'gantiPassword'])->name('profil.password');

    Route::prefix('pkl')->name('pkl.')->group(function () {
        Route::get('/pengajuan',      [SiswaPkl::class, 'index'])->name('pengajuan');
        Route::get('/pengajuan/buat', [SiswaPkl::class, 'create'])->name('pengajuan.create');
        Route::post('/pengajuan',     [SiswaPkl::class, 'store'])->name('pengajuan.store');
        Route::get('/pengajuan/{id}', [SiswaPkl::class, 'show'])->name('pengajuan.show');
    });

    Route::get('/jurnal',           [SiswaJurnal::class, 'index'])->name('jurnal');
    Route::get('/jurnal/tambah',    [SiswaJurnal::class, 'create'])->name('jurnal.create');
    Route::post('/jurnal',          [SiswaJurnal::class, 'store'])->name('jurnal.store');
    Route::get('/jurnal/{id}/edit', [SiswaJurnal::class, 'edit'])->name('jurnal.edit');
    Route::put('/jurnal/{id}',      [SiswaJurnal::class, 'update'])->name('jurnal.update');
    Route::delete('/jurnal/{id}',   [SiswaJurnal::class, 'destroy'])->name('jurnal.destroy');

    Route::get('/absensi', [SiswaAbsensi::class, 'index'])->name('absensi');

    Route::get('/laporan',              [SiswaLaporan::class, 'index'])->name('laporan');
    Route::get('/laporan/buat',         [SiswaLaporan::class, 'create'])->name('laporan.create');
    Route::post('/laporan',             [SiswaLaporan::class, 'store'])->name('laporan.store');
    Route::get('/laporan/{id}',         [SiswaLaporan::class, 'show'])->name('laporan.show');
    Route::post('/laporan/{id}/upload', [SiswaLaporan::class, 'upload'])->name('laporan.upload');

    Route::get('/nilai', [SiswaNilai::class, 'index'])->name('nilai');
    Route::get('/log',   [SiswaLog::class, 'index'])->name('log');
});

// ── PEMBIMBING / WAKASEK / ADMIN ──────────────────────────
Route::middleware(['auth','role:pembimbing'])->prefix('pembimbing')->name('pembimbing.')->group(function () {
    Route::get('/dashboard', fn() => view('pembimbing.dashboard'))->name('dashboard');
});
Route::middleware(['auth','role:wakasek'])->prefix('wakasek')->name('wakasek.')->group(function () {
    Route::get('/dashboard', fn() => view('wakasek.dashboard'))->name('dashboard');
});
Route::middleware(['auth','role:admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', fn() => view('admin.dashboard'))->name('dashboard');
});
