<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk — SIMPKL</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&family=Syne:wght@700;800&display=swap" rel="stylesheet">
    <style>
        *,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
        :root{--primary:#667eea;--gradient:linear-gradient(135deg,#667eea 0%,#764ba2 100%);--bg:#F8F9FA;--surface:#fff;--text:#1a1a2e;--text-muted:#6b7280;--border:rgba(102,126,234,0.15);--shadow:0 20px 60px rgba(102,126,234,0.18);--r-md:12px;--r-lg:16px;--r-xl:20px;--r-full:9999px;--fs-sm:0.8125rem;--fs-base:0.9375rem;--fs-lg:1.125rem}
        body{font-family:'DM Sans',sans-serif;font-size:var(--fs-base);line-height:1.65;background:var(--bg);color:var(--text);min-height:100vh;display:grid;place-items:center;-webkit-font-smoothing:antialiased}
        body::before{content:'';position:fixed;inset:0;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.03'/%3E%3C/svg%3E");pointer-events:none;z-index:0}

        .orb{position:fixed;border-radius:50%;filter:blur(80px);opacity:.3;animation:floatOrb 8s ease-in-out infinite}
        .orb-1{width:400px;height:400px;background:radial-gradient(circle,#667eea,transparent);top:-100px;right:-100px;animation-delay:0s}
        .orb-2{width:300px;height:300px;background:radial-gradient(circle,#764ba2,transparent);bottom:0;left:10%;animation-delay:3s}
        @keyframes floatOrb{0%,100%{transform:translateY(0) scale(1)}50%{transform:translateY(-20px) scale(1.03)}}

        .login-card{
            position:relative;z-index:1;
            background:var(--surface);
            border-radius:var(--r-xl);
            box-shadow:var(--shadow);
            border:1px solid var(--border);
            padding:40px;
            width:100%;max-width:420px;
            margin:20px;
        }
        .logo{display:flex;align-items:center;gap:10px;justify-content:center;margin-bottom:28px}
        .logo-icon{width:44px;height:44px;background:var(--gradient);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:20px}
        .logo-text{font-family:'Syne',sans-serif;font-size:1.5rem;font-weight:800;background:var(--gradient);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}

        h1{font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:800;text-align:center;color:var(--text);margin-bottom:4px}
        .subtitle{text-align:center;font-size:var(--fs-sm);color:var(--text-muted);margin-bottom:28px}

        .form-group{margin-bottom:16px}
        .form-label{display:block;font-size:var(--fs-sm);font-weight:600;color:var(--text);margin-bottom:6px}
        .form-control{width:100%;padding:11px 14px;border:1.5px solid var(--border);border-radius:var(--r-md);font-family:'DM Sans',sans-serif;font-size:var(--fs-sm);color:var(--text);background:var(--surface);transition:border-color .2s,box-shadow .2s;outline:none}
        .form-control:focus{border-color:var(--primary);box-shadow:0 0 0 3px rgba(102,126,234,.12)}
        .form-control.is-invalid{border-color:#ef4444}
        .invalid-feedback{font-size:0.72rem;color:#ef4444;margin-top:4px}

        .alert-error{background:rgba(239,68,68,.1);color:#dc2626;border:1px solid rgba(239,68,68,.2);border-radius:var(--r-md);padding:10px 14px;font-size:var(--fs-sm);margin-bottom:16px}

        .btn-login{
            width:100%;padding:12px;background:var(--gradient);color:white;border:none;
            border-radius:var(--r-full);font-family:'DM Sans',sans-serif;font-size:var(--fs-base);
            font-weight:700;cursor:pointer;box-shadow:0 4px 14px rgba(102,126,234,.35);
            transition:all .25s;margin-top:8px;
        }
        .btn-login:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(102,126,234,.45)}

        .back-link{display:block;text-align:center;margin-top:16px;font-size:var(--fs-sm);color:var(--text-muted);text-decoration:none}
        .back-link span{color:var(--primary);font-weight:600}
        .back-link:hover span{text-decoration:underline}

        .divider{display:flex;align-items:center;gap:12px;margin:20px 0;color:var(--text-muted);font-size:var(--fs-sm)}
        .divider::before,.divider::after{content:'';flex:1;height:1px;background:var(--border)}
    </style>
</head>
<body>
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>

    <div class="login-card">
        <div class="logo">
            <div class="logo-icon">🎓</div>
            <span class="logo-text">SIMPKL</span>
        </div>

        <h1>Selamat Datang</h1>
        <p class="subtitle">Masuk ke akun SIMPKL Anda</p>

        @if($errors->any())
            <div class="alert-error">{{ $errors->first() }}</div>
        @endif

        @if(session('success'))
            <div style="background:rgba(34,197,94,.1);color:#15803d;border:1px solid rgba(34,197,94,.2);border-radius:12px;padding:10px 14px;font-size:0.8125rem;margin-bottom:16px">
                ✅ {{ session('success') }}
            </div>
        @endif

        <form action="{{ route('login') }}" method="POST">
            @csrf

            <div class="form-group">
                <label class="form-label" for="email">Email</label>
                <input
                    type="email" id="email" name="email"
                    class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                    value="{{ old('email') }}"
                    placeholder="nama@sekolah.sch.id"
                    autocomplete="email"
                    required
                >
                @error('email')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label class="form-label" for="password">Password</label>
                <input
                    type="password" id="password" name="password"
                    class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                    placeholder="••••••••"
                    autocomplete="current-password"
                    required
                >
                @error('password')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div style="display:flex;align-items:center;justify-content:space-between;font-size:0.8125rem;margin-bottom:4px">
                <label style="display:flex;align-items:center;gap:6px;color:var(--text-muted);cursor:pointer">
                    <input type="checkbox" name="remember" style="accent-color:var(--primary)"> Ingat saya
                </label>
            </div>

            <button type="submit" class="btn-login">Masuk →</button>
        </form>

        <a href="{{ route('home') }}" class="back-link">← Kembali ke <span>beranda</span></a>
    </div>
</body>
</html>
