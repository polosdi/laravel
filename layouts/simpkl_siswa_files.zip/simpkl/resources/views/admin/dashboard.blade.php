<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin — SIMPKL</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&family=Syne:wght@700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>

    <style>
        *, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }

        :root {
            --primary:     #667eea;
            --primary-end: #764ba2;
            --gradient:    linear-gradient(135deg,#667eea 0%,#764ba2 100%);
            --bg:          #F8F9FA;
            --surface:     #ffffff;
            --text:        #1a1a2e;
            --muted:       #6b7280;
            --light:       #9ca3af;
            --border:      rgba(102,126,234,.15);
            --shadow:      0 20px 60px rgba(102,126,234,.15);
            --shadow-sm:   0 4px 16px rgba(102,126,234,.10);
            --sidebar-w:   260px;

            /* accent colors */
            --green:  #22c55e; --green-bg:  rgba(34,197,94,.1);
            --amber:  #f59e0b; --amber-bg:  rgba(245,158,11,.1);
            --red:    #ef4444; --red-bg:    rgba(239,68,68,.1);
            --blue:   #3b82f6; --blue-bg:   rgba(59,130,246,.1);
            --pink:   #ec4899; --pink-bg:   rgba(236,72,153,.1);
            --teal:   #14b8a6; --teal-bg:   rgba(20,184,166,.1);

            --r-sm:4px; --r-md:12px; --r-lg:16px; --r-xl:20px; --r-2xl:24px; --r-full:9999px;
        }

        body {
            font-family:'DM Sans',sans-serif;
            font-size:.9375rem;
            line-height:1.65;
            background:var(--bg);
            color:var(--text);
            overflow-x:hidden;
            -webkit-font-smoothing:antialiased;
        }

        body::before {
            content:'';
            position:fixed; inset:0;
            background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.03'/%3E%3C/svg%3E");
            pointer-events:none; z-index:0;
        }

        /* ══════════ SIDEBAR ══════════ */
        .sidebar {
            position:fixed; top:0; left:0;
            width:var(--sidebar-w); height:100vh;
            background:var(--surface);
            border-right:1px solid var(--border);
            box-shadow:var(--shadow-sm);
            display:flex; flex-direction:column;
            z-index:200; transition:transform .3s ease;
        }

        .sidebar-logo {
            display:flex; align-items:center; gap:10px;
            padding:24px 20px 20px;
            border-bottom:1px solid var(--border);
            text-decoration:none;
        }

        .logo-icon {
            width:38px; height:38px;
            background:var(--gradient);
            border-radius:10px;
            display:flex; align-items:center; justify-content:center;
            font-size:17px; flex-shrink:0;
        }

        .logo-text {
            font-family:'Syne',sans-serif;
            font-size:1.2rem; font-weight:800;
            background:var(--gradient);
            -webkit-background-clip:text;
            -webkit-text-fill-color:transparent;
            background-clip:text;
        }

        .sidebar-user {
            padding:16px 20px;
            display:flex; align-items:center; gap:10px;
            border-bottom:1px solid var(--border);
        }

        .s-avatar {
            width:40px; height:40px;
            background:var(--gradient);
            border-radius:50%;
            display:flex; align-items:center; justify-content:center;
            font-family:'Syne',sans-serif; font-weight:800;
            font-size:.85rem; color:white; flex-shrink:0;
        }

        .s-name  { font-weight:600; font-size:.8125rem; color:var(--text); line-height:1.2; }
        .s-role  { font-size:.75rem; color:var(--primary); font-weight:500; }

        .sidebar-nav { flex:1; overflow-y:auto; padding:12px; }

        .nav-section {
            font-size:10px; font-weight:700;
            letter-spacing:.08em; text-transform:uppercase;
            color:var(--light); padding:8px 8px 4px; margin-top:4px;
        }

        .nav-item {
            display:flex; align-items:center; gap:10px;
            padding:9px 12px; border-radius:var(--r-md);
            text-decoration:none; color:var(--muted);
            font-weight:500; font-size:.8125rem;
            transition:all .2s; margin-bottom:2px;
        }

        .nav-item:hover { background:rgba(102,126,234,.07); color:var(--primary); }

        .nav-item.active {
            background:linear-gradient(135deg,rgba(102,126,234,.14),rgba(118,75,162,.10));
            color:var(--primary); font-weight:600;
        }

        .nav-icon { width:20px; height:20px; display:flex; align-items:center; justify-content:center; font-size:16px; flex-shrink:0; }

        .nav-badge {
            margin-left:auto;
            background:var(--red); color:white;
            font-size:10px; font-weight:700;
            padding:2px 7px; border-radius:var(--r-full);
        }

        .sidebar-footer { padding:16px 12px; border-top:1px solid var(--border); }

        .btn-logout {
            display:flex; align-items:center; gap:8px;
            padding:9px 14px; border-radius:var(--r-md);
            width:100%; background:transparent;
            border:1.5px solid rgba(239,68,68,.25);
            color:var(--red); font-family:'DM Sans',sans-serif;
            font-size:.8125rem; font-weight:600;
            cursor:pointer; transition:all .2s;
        }
        .btn-logout:hover { background:rgba(239,68,68,.07); border-color:var(--red); }

        /* ══════════ TOPBAR ══════════ */
        .topbar {
            position:fixed; top:0;
            left:var(--sidebar-w); right:0; height:64px;
            background:rgba(248,249,250,.92);
            backdrop-filter:blur(20px);
            border-bottom:1px solid var(--border);
            display:flex; align-items:center;
            justify-content:space-between;
            padding:0 28px; z-index:100;
        }

        .page-title  { font-family:'Syne',sans-serif; font-size:1.25rem; font-weight:800; }
        .page-sub    { font-size:.75rem; color:var(--muted); margin-top:-2px; }

        .topbar-right { display:flex; align-items:center; gap:10px; }

        .tb-chip {
            font-size:.75rem; color:var(--muted);
            background:rgba(102,126,234,.06);
            border:1px solid var(--border);
            padding:5px 12px; border-radius:var(--r-full);
        }

        .tb-btn {
            width:36px; height:36px;
            background:var(--surface);
            border:1.5px solid var(--border);
            border-radius:var(--r-md);
            display:flex; align-items:center; justify-content:center;
            font-size:15px; cursor:pointer;
            position:relative; transition:all .2s;
        }
        .tb-btn:hover { border-color:var(--primary); }

        .notif-dot {
            position:absolute; top:5px; right:5px;
            width:7px; height:7px;
            background:var(--red); border-radius:50%;
            border:1.5px solid white;
        }

        /* ══════════ MAIN ══════════ */
        .main {
            margin-left:var(--sidebar-w); margin-top:64px;
            padding:28px; position:relative; z-index:1;
            min-height:calc(100vh - 64px);
        }

        /* ══════════ HERO BANNER ══════════ */
        .hero {
            background:var(--gradient);
            border-radius:var(--r-2xl);
            padding:26px 32px;
            margin-bottom:24px;
            position:relative; overflow:hidden;
            display:flex; align-items:center;
            justify-content:space-between; gap:20px;
        }

        .hero::before {
            content:''; position:absolute;
            top:-50px; right:-50px;
            width:220px; height:220px;
            background:rgba(255,255,255,.08);
            border-radius:50%;
        }
        .hero::after {
            content:''; position:absolute;
            bottom:-70px; left:28%;
            width:280px; height:280px;
            background:rgba(255,255,255,.05);
            border-radius:50%;
        }

        .hero-text { z-index:1; }
        .hero-greeting { font-size:.8125rem; color:rgba(255,255,255,.7); font-weight:500; }
        .hero-title {
            font-family:'Syne',sans-serif; font-size:1.5rem;
            font-weight:800; color:white; margin:4px 0 10px;
        }

        .hero-chips { display:flex; gap:10px; flex-wrap:wrap; }
        .hero-chip {
            display:inline-flex; align-items:center; gap:5px;
            font-size:.75rem; font-weight:600;
            color:rgba(255,255,255,.85);
            background:rgba(255,255,255,.14);
            padding:4px 12px; border-radius:var(--r-full);
        }

        .hero-stats {
            display:flex; gap:12px; z-index:1; flex-shrink:0;
        }

        .hero-stat {
            background:rgba(255,255,255,.14);
            border:1.5px solid rgba(255,255,255,.22);
            border-radius:var(--r-xl);
            padding:14px 20px; text-align:center;
        }

        .hs-num {
            font-family:'Syne',sans-serif; font-size:1.5rem;
            font-weight:800; color:white; line-height:1;
        }

        .hs-label { font-size:.7rem; color:rgba(255,255,255,.65); font-weight:600; margin-top:3px; }

        /* ══════════ STAT CARDS ══════════ */
        .stats-grid {
            display:grid;
            grid-template-columns:repeat(4,1fr);
            gap:16px; margin-bottom:24px;
        }

        .sc {
            background:var(--surface);
            border-radius:var(--r-xl);
            padding:20px;
            border:1px solid var(--border);
            box-shadow:var(--shadow-sm);
            position:relative; overflow:hidden;
            transition:transform .2s,box-shadow .2s;
        }
        .sc:hover { transform:translateY(-3px); box-shadow:var(--shadow); }

        .sc::before {
            content:''; position:absolute;
            top:0; right:0; width:70px; height:70px;
            border-radius:0 var(--r-xl) 0 70px;
        }

        .sc-purple::before  { background:rgba(102,126,234,.12); }
        .sc-green::before   { background:rgba(34,197,94,.12); }
        .sc-amber::before   { background:rgba(245,158,11,.12); }
        .sc-red::before     { background:rgba(239,68,68,.12); }
        .sc-blue::before    { background:rgba(59,130,246,.12); }
        .sc-pink::before    { background:rgba(236,72,153,.12); }
        .sc-teal::before    { background:rgba(20,184,166,.12); }
        .sc-indigo::before  { background:rgba(99,102,241,.12); }

        .sc-icon {
            width:42px; height:42px;
            border-radius:var(--r-md);
            display:flex; align-items:center; justify-content:center;
            font-size:20px; margin-bottom:14px;
        }

        .icon-purple { background:linear-gradient(135deg,rgba(102,126,234,.15),rgba(118,75,162,.08)); }
        .icon-green  { background:linear-gradient(135deg,rgba(34,197,94,.15),rgba(22,163,74,.08)); }
        .icon-amber  { background:linear-gradient(135deg,rgba(245,158,11,.15),rgba(217,119,6,.08)); }
        .icon-red    { background:linear-gradient(135deg,rgba(239,68,68,.15),rgba(220,38,38,.08)); }
        .icon-blue   { background:linear-gradient(135deg,rgba(59,130,246,.15),rgba(37,99,235,.08)); }
        .icon-pink   { background:linear-gradient(135deg,rgba(236,72,153,.15),rgba(219,39,119,.08)); }
        .icon-teal   { background:linear-gradient(135deg,rgba(20,184,166,.15),rgba(13,148,136,.08)); }
        .icon-indigo { background:linear-gradient(135deg,rgba(99,102,241,.15),rgba(79,70,229,.08)); }

        .sc-num {
            font-family:'Syne',sans-serif;
            font-size:1.9rem; font-weight:800;
            letter-spacing:-.02em; color:var(--text);
            line-height:1; margin-bottom:4px;
        }

        .sc-label { font-size:.75rem; color:var(--muted); font-weight:500; }

        .sc-sub {
            font-size:.75rem; margin-top:10px; padding-top:10px;
            border-top:1px solid var(--border); color:var(--muted);
            display:flex; align-items:center; gap:6px;
        }

        .tag {
            display:inline-flex; align-items:center; gap:3px;
            font-size:.7rem; font-weight:700;
            padding:2px 7px; border-radius:var(--r-full);
        }
        .tag-green  { background:var(--green-bg); color:var(--green); }
        .tag-amber  { background:var(--amber-bg); color:var(--amber); }
        .tag-red    { background:var(--red-bg);   color:var(--red); }
        .tag-blue   { background:var(--blue-bg);  color:var(--blue); }
        .tag-purple { background:rgba(102,126,234,.1); color:var(--primary); }

        /* ══════════ CARD ══════════ */
        .card {
            background:var(--surface);
            border-radius:var(--r-xl);
            border:1px solid var(--border);
            box-shadow:var(--shadow-sm);
            overflow:hidden;
        }

        .card-header {
            padding:18px 20px 14px;
            border-bottom:1px solid var(--border);
            display:flex; align-items:center; justify-content:space-between;
        }

        .card-title {
            font-family:'Syne',sans-serif;
            font-size:1.05rem; font-weight:700; color:var(--text);
        }

        .card-body { padding:16px 20px; }
        .card-link {
            font-size:.75rem; font-weight:600;
            color:var(--primary); text-decoration:none;
        }
        .card-link:hover { opacity:.7; }

        /* ══════════ GRID LAYOUTS ══════════ */
        .grid-2-1 {
            display:grid;
            grid-template-columns:1fr 360px;
            gap:20px; margin-bottom:20px;
        }

        .grid-3 {
            display:grid;
            grid-template-columns:repeat(3,1fr);
            gap:20px; margin-bottom:20px;
        }

        .grid-2 {
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:20px; margin-bottom:20px;
        }

        /* ══════════ TABLE ══════════ */
        .table-wrap { overflow-x:auto; }

        table { width:100%; border-collapse:collapse; font-size:.8125rem; }

        thead th {
            font-size:.7rem; font-weight:700;
            text-transform:uppercase; letter-spacing:.05em;
            color:var(--muted); padding:10px 14px;
            text-align:left;
            border-bottom:1.5px solid var(--border);
            white-space:nowrap;
        }

        tbody td {
            padding:11px 14px;
            border-bottom:1px solid var(--border);
            color:var(--text); vertical-align:middle;
        }

        tbody tr:last-child td { border-bottom:none; }
        tbody tr:hover td { background:rgba(102,126,234,.025); }

        /* ══════════ BADGES ══════════ */
        .badge {
            display:inline-flex; align-items:center; gap:3px;
            font-size:.65rem; font-weight:700;
            padding:3px 9px; border-radius:var(--r-full);
        }
        .badge-pending   { background:var(--amber-bg); color:var(--amber); }
        .badge-disetujui { background:var(--green-bg); color:var(--green); }
        .badge-ditolak   { background:var(--red-bg);   color:var(--red); }
        .badge-revisi    { background:var(--blue-bg);  color:var(--blue); }
        .badge-valid     { background:var(--green-bg); color:var(--green); }
        .badge-siswa     { background:rgba(102,126,234,.1); color:var(--primary); }
        .badge-pembimbing{ background:var(--teal-bg);  color:var(--teal); }
        .badge-wakasek   { background:var(--amber-bg); color:var(--amber); }
        .badge-admin     { background:var(--pink-bg);  color:var(--pink); }

        /* ══════════ CHART AREA ══════════ */
        .chart-wrap {
            position:relative; padding:8px 0;
        }

        /* ══════════ PROGRESS BAR ══════════ */
        .prog-row { margin-bottom:14px; }
        .prog-row:last-child { margin-bottom:0; }

        .prog-top {
            display:flex; justify-content:space-between;
            font-size:.75rem; margin-bottom:5px;
        }

        .prog-label { font-weight:500; color:var(--text); }
        .prog-val   { font-weight:700; color:var(--text); }

        .prog-bar {
            height:7px; background:rgba(102,126,234,.08);
            border-radius:var(--r-full); overflow:hidden;
        }
        .prog-fill {
            height:100%; background:var(--gradient);
            border-radius:var(--r-full);
            transition:width 1.2s cubic-bezier(.4,0,.2,1);
        }

        /* ══════════ LOG AKTIVITAS ══════════ */
        .log-list { list-style:none; }

        .log-item {
            display:flex; gap:12px;
            padding:10px 0;
            border-bottom:1px solid var(--border);
            align-items:flex-start;
        }
        .log-item:last-child { border-bottom:none; }

        .log-avatar {
            width:34px; height:34px; flex-shrink:0;
            background:var(--gradient);
            border-radius:50%;
            display:flex; align-items:center; justify-content:center;
            font-family:'Syne',sans-serif; font-weight:800;
            font-size:.7rem; color:white;
        }

        .log-text  { font-size:.8125rem; font-weight:500; color:var(--text); line-height:1.4; }
        .log-meta  { font-size:.7rem; color:var(--light); margin-top:2px; }

        /* ══════════ USER TERBARU ══════════ */
        .user-row {
            display:flex; align-items:center; gap:12px;
            padding:10px 0; border-bottom:1px solid var(--border);
        }
        .user-row:last-child { border-bottom:none; }

        .u-avatar {
            width:36px; height:36px; flex-shrink:0;
            background:var(--gradient); border-radius:50%;
            display:flex; align-items:center; justify-content:center;
            font-family:'Syne',sans-serif; font-weight:800;
            font-size:.75rem; color:white;
        }

        .u-name  { font-size:.8125rem; font-weight:600; color:var(--text); }
        .u-meta  { font-size:.7rem; color:var(--light); }

        /* ══════════ NILAI RING ══════════ */
        .nilai-ring {
            display:flex; flex-direction:column; align-items:center;
            padding:20px 0 10px;
        }

        .ring-num {
            font-family:'Syne',sans-serif; font-size:3rem; font-weight:800;
            background:var(--gradient);
            -webkit-background-clip:text;
            -webkit-text-fill-color:transparent;
            background-clip:text; line-height:1;
        }

        .ring-label { font-size:.75rem; color:var(--muted); margin-top:6px; }

        .predikat-row {
            display:flex; justify-content:space-between; align-items:center;
            padding:9px 0; border-bottom:1px solid var(--border);
            font-size:.8125rem;
        }
        .predikat-row:last-child { border-bottom:none; }
        .predikat-letter {
            font-family:'Syne',sans-serif; font-weight:800;
            font-size:1.1rem; color:var(--text);
        }

        /* ══════════ QUICK ACTIONS ══════════ */
        .qa-grid { display:grid; grid-template-columns:1fr 1fr; gap:10px; }

        .qa-btn {
            display:flex; align-items:center; gap:10px;
            padding:12px 14px;
            background:rgba(102,126,234,.05);
            border:1.5px solid rgba(102,126,234,.15);
            border-radius:var(--r-lg);
            text-decoration:none; color:var(--text);
            font-size:.8125rem; font-weight:500;
            transition:all .2s;
        }
        .qa-btn:hover {
            background:rgba(102,126,234,.1);
            border-color:rgba(102,126,234,.3);
            color:var(--primary);
        }

        .qa-icon {
            width:34px; height:34px; flex-shrink:0;
            background:var(--gradient); border-radius:var(--r-md);
            display:flex; align-items:center; justify-content:center;
            font-size:15px;
        }

        /* ══════════ OVERLAY & MOBILE ══════════ */
        .overlay {
            display:none; position:fixed; inset:0;
            background:rgba(0,0,0,.35); z-index:150;
        }
        .overlay.show { display:block; }

        .mobile-toggle {
            display:none; background:none;
            border:none; font-size:22px;
            cursor:pointer; color:var(--text);
        }

        /* ══════════ ANIMATIONS ══════════ */
        @keyframes fadeUp {
            from { opacity:0; transform:translateY(16px); }
            to   { opacity:1; transform:translateY(0); }
        }

        .main > * { animation:fadeUp .5s ease both; }
        .main > *:nth-child(1) { animation-delay:0s; }
        .main > *:nth-child(2) { animation-delay:.07s; }
        .main > *:nth-child(3) { animation-delay:.14s; }
        .main > *:nth-child(4) { animation-delay:.21s; }
        .main > *:nth-child(5) { animation-delay:.28s; }
        .main > *:nth-child(6) { animation-delay:.35s; }

        /* ══════════ RESPONSIVE ══════════ */
        @media (max-width:1280px) {
            .stats-grid { grid-template-columns:repeat(2,1fr); }
            .grid-2-1, .grid-3 { grid-template-columns:1fr; }
            .grid-2 { grid-template-columns:1fr; }
        }
        @media (max-width:768px) {
            :root { --sidebar-w:0px; }
            .sidebar { transform:translateX(-260px); }
            .sidebar.open { transform:translateX(0); }
            .main { margin-left:0; }
            .topbar { left:0; }
            .stats-grid { grid-template-columns:1fr 1fr; }
            .hero { flex-direction:column; }
            .hero-stats { width:100%; justify-content:center; }
            .mobile-toggle { display:block; }
        }
    </style>
</head>
<body>

<div class="overlay" id="overlay" onclick="closeSidebar()"></div>

<!-- ══════════ SIDEBAR ══════════ -->
<aside class="sidebar" id="sidebar">
    <a class="sidebar-logo" href="{{ route('home') }}">
        <div class="logo-icon">🎓</div>
        <span class="logo-text">SIMPKL</span>
    </a>

    <div class="sidebar-user">
        <div class="s-avatar">
            {{ strtoupper(substr(Auth::user()->nama_depan,0,1).substr(Auth::user()->nama_belakang,0,1)) }}
        </div>
        <div>
            <div class="s-name">{{ Auth::user()->nama_depan }} {{ Auth::user()->nama_belakang }}</div>
            <div class="s-role">Administrator</div>
        </div>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-section">Utama</div>
        <a href="{{ route('admin.dashboard') }}" class="nav-item active">
            <span class="nav-icon">🏠</span> Dashboard
        </a>

        <div class="nav-section">Manajemen</div>
        <a href="{{ route('admin.users.index') }}" class="nav-item">
            <span class="nav-icon">👥</span> Data Pengguna
            @if($pengajuanPending > 0)
                <span class="nav-badge">{{ $pengajuanPending }}</span>
            @endif
        </a>
        <a href="{{ route('admin.mitra.index') }}" class="nav-item">
            <span class="nav-icon">🏢</span> Mitra Industri
        </a>
        <a href="{{ route('admin.walikelas.index') }}" class="nav-item">
            <span class="nav-icon">👨‍🏫</span> Wali Kelas
        </a>

        <div class="nav-section">PKL</div>
        <a href="{{ route('admin.pkl.index') }}" class="nav-item">
            <span class="nav-icon">📋</span> Pengajuan PKL
        </a>
        <a href="{{ route('admin.jurnal.index') }}" class="nav-item">
            <span class="nav-icon">📓</span> Jurnal Harian
        </a>
        <a href="{{ route('admin.absensi.index') }}" class="nav-item">
            <span class="nav-icon">📅</span> Absensi
        </a>
        <a href="{{ route('admin.laporan.index') }}" class="nav-item">
            <span class="nav-icon">📄</span> Laporan PKL
        </a>
        <a href="{{ route('admin.nilai.index') }}" class="nav-item">
            <span class="nav-icon">⭐</span> Nilai PKL
        </a>

        <div class="nav-section">Sistem</div>
        <a href="{{ route('admin.log.index') }}" class="nav-item">
            <span class="nav-icon">🕐</span> Log Aktivitas
        </a>
    </nav>

    <div class="sidebar-footer">
        <form action="{{ route('logout') }}" method="POST">
            @csrf
            <button type="submit" class="btn-logout">
                <span>🚪</span> Keluar
            </button>
        </form>
    </div>
</aside>

<!-- ══════════ TOPBAR ══════════ -->
<header class="topbar">
    <div style="display:flex;align-items:center;gap:12px;">
        <button class="mobile-toggle" onclick="openSidebar()">☰</button>
        <div>
            <div class="page-title">Dashboard Admin</div>
            <div class="page-sub">Ringkasan sistem SIMPKL secara keseluruhan</div>
        </div>
    </div>
    <div class="topbar-right">
        <span class="tb-chip">📅 {{ now()->translatedFormat('d F Y') }}</span>
        <div class="tb-btn" title="Notifikasi">
            🔔 <span class="notif-dot"></span>
        </div>
        <a href="{{ route('admin.users.create') }}" style="display:flex;align-items:center;gap:6px;padding:8px 16px;background:var(--gradient);color:white;border-radius:var(--r-full);text-decoration:none;font-size:.8125rem;font-weight:600;box-shadow:0 4px 12px rgba(102,126,234,.35);">
            + Tambah User
        </a>
    </div>
</header>

<!-- ══════════ MAIN ══════════ -->
<main class="main">

    <!-- ── HERO BANNER ─────────────────────────────────── -->
    {{--
        Variabel: $totalUser, $siswaAktifPkl, $pengajuanPending, $totalMitra
    --}}
    <div class="hero">
        <div class="hero-text">
            <div class="hero-greeting">Selamat datang kembali, Admin!</div>
            <div class="hero-title">Panel Kontrol SIMPKL</div>
            <div class="hero-chips">
                <span class="hero-chip">👥 {{ $totalUser }} Pengguna Terdaftar</span>
                <span class="hero-chip">🏢 {{ $totalMitra }} Mitra Industri</span>
                <span class="hero-chip">📊 Tahun Ajaran 2024/2025</span>
            </div>
        </div>
        <div class="hero-stats">
            <div class="hero-stat">
                <div class="hs-num">{{ $siswaAktifPkl }}</div>
                <div class="hs-label">Siswa Aktif PKL</div>
            </div>
            <div class="hero-stat">
                <div class="hs-num" style="color:#fcd34d;">{{ $pengajuanPending }}</div>
                <div class="hs-label">Menunggu Approve</div>
            </div>
            <div class="hero-stat">
                <div class="hs-num">{{ $rataKehadiran }}%</div>
                <div class="hs-label">Rata Kehadiran</div>
            </div>
        </div>
    </div>

    <!-- ── 8 STAT CARDS ────────────────────────────────── -->
    {{--
        Variabel: $totalSiswa, $totalPembimbing, $totalPengajuan, $pengajuanDisetujui,
                  $pengajuanDitolak, $totalJurnal, $jurnalPending, $jurnalValid,
                  $totalLaporan, $laporanPending, $laporanDisetujui, $laporanRevisi,
                  $rataRataNilai
    --}}
    <div class="stats-grid">
        <div class="sc sc-purple">
            <div class="sc-icon icon-purple">👥</div>
            <div class="sc-num">{{ $totalSiswa }}</div>
            <div class="sc-label">Total Siswa</div>
            <div class="sc-sub">
                <span class="tag tag-purple">{{ $totalPembimbing }} pembimbing</span>
                <span>· {{ $totalWakasek }} wakasek</span>
            </div>
        </div>

        <div class="sc sc-green">
            <div class="sc-icon icon-green">✅</div>
            <div class="sc-num">{{ $pengajuanDisetujui }}</div>
            <div class="sc-label">PKL Disetujui</div>
            <div class="sc-sub">
                <span class="tag tag-amber">{{ $pengajuanPending }} pending</span>
                <span class="tag tag-red" style="margin-left:4px;">{{ $pengajuanDitolak }} ditolak</span>
            </div>
        </div>

        <div class="sc sc-amber">
            <div class="sc-icon icon-amber">📓</div>
            <div class="sc-num">{{ $totalJurnal }}</div>
            <div class="sc-label">Total Jurnal</div>
            <div class="sc-sub">
                <span class="tag tag-green">{{ $jurnalValid }} valid</span>
                <span class="tag tag-amber" style="margin-left:4px;">{{ $jurnalPending }} pending</span>
            </div>
        </div>

        <div class="sc sc-blue">
            <div class="sc-icon icon-blue">📄</div>
            <div class="sc-num">{{ $totalLaporan }}</div>
            <div class="sc-label">Laporan PKL</div>
            <div class="sc-sub">
                <span class="tag tag-green">{{ $laporanDisetujui }} disetujui</span>
                <span style="margin-left:4px;">· {{ $laporanRevisi }} revisi</span>
            </div>
        </div>

        <div class="sc sc-pink">
            <div class="sc-icon icon-pink">⭐</div>
            <div class="sc-num">{{ $rataRataNilai ? number_format($rataRataNilai,1) : '—' }}</div>
            <div class="sc-label">Rata-rata Nilai</div>
            <div class="sc-sub">
                @php
                    $pred = $rataRataNilai ? \App\Models\NilaiPkl::tentukanPredikat($rataRataNilai) : '—';
                @endphp
                Predikat rata-rata: <span class="tag tag-green" style="margin-left:4px;">{{ $pred }}</span>
            </div>
        </div>

        <div class="sc sc-teal">
            <div class="sc-icon icon-teal">📅</div>
            <div class="sc-num">{{ $rataKehadiran }}%</div>
            <div class="sc-label">Tingkat Kehadiran</div>
            <div class="sc-sub">
                <span class="tag tag-green">{{ $totalHadir ?? 0 }} hadir</span>
                dari {{ $totalAbsensi }} data
            </div>
        </div>

        <div class="sc sc-indigo">
            <div class="sc-icon icon-indigo">🏢</div>
            <div class="sc-num">{{ $totalMitra }}</div>
            <div class="sc-label">Mitra Industri</div>
            <div class="sc-sub">
                <span class="tag tag-purple">{{ $siswaAktifPkl }} siswa aktif</span>
            </div>
        </div>

        <div class="sc sc-red">
            <div class="sc-icon icon-red">🔔</div>
            <div class="sc-num">{{ $pengajuanPending + $jurnalPending + $laporanPending }}</div>
            <div class="sc-label">Perlu Tindakan</div>
            <div class="sc-sub">
                <span class="tag tag-red">Harus ditindaklanjuti</span>
            </div>
        </div>
    </div>

    <!-- ── CHART + PENGAJUAN TERBARU ───────────────────── -->
    {{--
        Variabel: $distribusiJurusan (collection: jurusan, total)
                  $pengajuanTerbaru (collection: ketua, pembimbing, nama_perusahaan, status_*)
    --}}
    <div class="grid-2-1">

        <!-- Pengajuan PKL Terbaru -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">Pengajuan PKL Terbaru</div>
                <a href="{{ route('admin.pkl.index') }}" class="card-link">Lihat semua →</a>
            </div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Siswa (Ketua)</th>
                            <th>Perusahaan</th>
                            <th>Pembimbing</th>
                            <th>Status Pembimbing</th>
                            <th>Status Wakasek</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($pengajuanTerbaru as $p)
                        <tr>
                            <td>
                                <div style="font-weight:600;">
                                    {{ $p->ketua?->nama_depan }} {{ $p->ketua?->nama_belakang }}
                                </div>
                                <div style="font-size:.7rem;color:var(--light);">
                                    {{ $p->tanggal_pengajuan?->format('d M Y') }}
                                </div>
                            </td>
                            <td>{{ $p->nama_perusahaan }}</td>
                            <td>{{ $p->pembimbing ? $p->pembimbing->nama_depan.' '.$p->pembimbing->nama_belakang : '—' }}</td>
                            <td><span class="badge badge-{{ $p->status_pembimbing }}">{{ ucfirst($p->status_pembimbing) }}</span></td>
                            <td><span class="badge badge-{{ $p->status_wakasek }}">{{ ucfirst($p->status_wakasek) }}</span></td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" style="text-align:center;padding:24px;color:var(--muted);">
                                Belum ada pengajuan PKL
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Distribusi Jurusan -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">Distribusi Jurusan</div>
                <a href="{{ route('admin.users.index') }}?role=siswa" class="card-link">Detail →</a>
            </div>
            <div class="card-body">
                @php
                    $maxJurusan = $distribusiJurusan->max('total') ?: 1;
                @endphp
                @forelse($distribusiJurusan as $item)
                <div class="prog-row">
                    <div class="prog-top">
                        <span class="prog-label">{{ $item->jurusan }}</span>
                        <span class="prog-val">{{ $item->total }} siswa</span>
                    </div>
                    <div class="prog-bar">
                        <div class="prog-fill"
                             style="width:{{ round($item->total / $maxJurusan * 100) }}%">
                        </div>
                    </div>
                </div>
                @empty
                <div style="text-align:center;padding:24px;color:var(--muted);">
                    Belum ada data jurusan
                </div>
                @endforelse
            </div>
        </div>
    </div>

    <!-- ── CHART PIE + LOG + NILAI ──────────────────────── -->
    {{--
        Variabel: $absensiPerStatus, $logTerbaru, $distribusiNilai, $rataRataNilai
    --}}
    <div class="grid-3">

        <!-- Chart Absensi (Donut) -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">Rekap Absensi</div>
                <a href="{{ route('admin.absensi.index') }}" class="card-link">Detail →</a>
            </div>
            <div class="card-body">
                <div class="chart-wrap" style="height:180px;">
                    <canvas id="chartAbsensi"></canvas>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px;">
                    @php
                        $statusList = ['Hadir','Izin','Sakit','Alpa'];
                        $statusColor = ['#22c55e','#f59e0b','#3b82f6','#ef4444'];
                    @endphp
                    @foreach($statusList as $i => $s)
                    <div style="display:flex;align-items:center;gap:6px;font-size:.75rem;">
                        <span style="width:10px;height:10px;border-radius:50%;background:{{ $statusColor[$i] }};flex-shrink:0;"></span>
                        <span style="color:var(--muted);">{{ $s }}</span>
                        <span style="margin-left:auto;font-weight:700;">{{ $absensiPerStatus[$s]->total ?? 0 }}</span>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>

        <!-- Log Aktivitas -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">Log Aktivitas</div>
                <a href="{{ route('admin.log.index') }}" class="card-link">Semua →</a>
            </div>
            <div class="card-body" style="padding-top:8px;">
                <ul class="log-list">
                    @forelse($logTerbaru as $log)
                    <li class="log-item">
                        <div class="log-avatar">
                            {{ $log->user ? strtoupper(substr($log->user->nama_depan,0,1).substr($log->user->nama_belakang,0,1)) : '??' }}
                        </div>
                        <div style="flex:1;min-width:0;">
                            <div class="log-text">{{ $log->aktivitas }}</div>
                            <div class="log-meta">
                                {{ $log->user?->nama_depan }} ·
                                {{ $log->waktu?->diffForHumans() }}
                            </div>
                        </div>
                    </li>
                    @empty
                    <li style="text-align:center;padding:20px;color:var(--muted);font-size:.8125rem;">
                        Belum ada log aktivitas
                    </li>
                    @endforelse
                </ul>
            </div>
        </div>

        <!-- Distribusi Nilai -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">Distribusi Nilai PKL</div>
                <a href="{{ route('admin.nilai.index') }}" class="card-link">Detail →</a>
            </div>
            <div class="card-body">
                <div class="nilai-ring">
                    <div class="ring-num">
                        {{ $rataRataNilai ? number_format($rataRataNilai,1) : '—' }}
                    </div>
                    <div class="ring-label">Rata-rata Nilai Akhir</div>
                </div>

                @php
                    $totalNilai = $distribusiNilai->sum('total') ?: 1;
                    $predColors = ['A'=>'#22c55e','B'=>'#3b82f6','C'=>'#f59e0b','D'=>'#f97316','E'=>'#ef4444'];
                @endphp
                @forelse($distribusiNilai as $n)
                <div class="predikat-row">
                    <div style="display:flex;align-items:center;gap:8px;">
                        <span style="width:10px;height:10px;border-radius:2px;background:{{ $predColors[$n->predikat] ?? '#9ca3af' }};flex-shrink:0;"></span>
                        <span class="predikat-letter">{{ $n->predikat }}</span>
                    </div>
                    <div style="flex:1;margin:0 12px;">
                        <div class="prog-bar" style="height:5px;">
                            <div class="prog-fill" style="width:{{ round($n->total/$totalNilai*100) }}%;background:{{ $predColors[$n->predikat] ?? 'var(--gradient)' }};"></div>
                        </div>
                    </div>
                    <span style="font-size:.75rem;font-weight:700;min-width:30px;text-align:right;">{{ $n->total }}</span>
                </div>
                @empty
                <div style="text-align:center;padding:16px;color:var(--muted);font-size:.8125rem;">
                    Belum ada data nilai
                </div>
                @endforelse
            </div>
        </div>
    </div>

    <!-- ── USER TERBARU + MITRA + QUICK ACTIONS ─────────── -->
    {{--
        Variabel: $userTerbaru, $mitraPopuler
    --}}
    <div class="grid-3">

        <!-- Siswa Terbaru Daftar -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">Siswa Terbaru</div>
                <a href="{{ route('admin.users.index') }}?role=siswa" class="card-link">Semua →</a>
            </div>
            <div class="card-body">
                @forelse($userTerbaru as $u)
                <div class="user-row">
                    <div class="u-avatar">
                        {{ strtoupper(substr($u->nama_depan,0,1).substr($u->nama_belakang,0,1)) }}
                    </div>
                    <div style="flex:1;min-width:0;">
                        <div class="u-name">{{ $u->nama_depan }} {{ $u->nama_belakang }}</div>
                        <div class="u-meta">
                            {{ $u->profilSiswa?->jurusan ?? 'Jurusan belum diisi' }}
                            · {{ $u->profilSiswa?->kelas ?? '—' }}
                        </div>
                    </div>
                    <span class="badge badge-siswa">Siswa</span>
                </div>
                @empty
                <div style="text-align:center;padding:20px;color:var(--muted);font-size:.8125rem;">
                    Belum ada siswa terdaftar
                </div>
                @endforelse
            </div>
        </div>

        <!-- Mitra Paling Populer -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">Mitra Terpopuler</div>
                <a href="{{ route('admin.mitra.index') }}" class="card-link">Semua →</a>
            </div>
            <div class="card-body">
                @php $maxMitra = $mitraPopuler->max('total') ?: 1; @endphp
                @forelse($mitraPopuler as $m)
                <div class="prog-row">
                    <div class="prog-top">
                        <span class="prog-label" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:180px;">
                            {{ $m->nama_perusahaan }}
                        </span>
                        <span class="prog-val">{{ $m->total }}</span>
                    </div>
                    <div class="prog-bar">
                        <div class="prog-fill" style="width:{{ round($m->total/$maxMitra*100) }}%"></div>
                    </div>
                </div>
                @empty
                <div style="text-align:center;padding:24px;color:var(--muted);font-size:.8125rem;">
                    Belum ada data PKL disetujui
                </div>
                @endforelse
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="card">
            <div class="card-header">
                <div class="card-title">Aksi Cepat</div>
            </div>
            <div class="card-body">
                <div class="qa-grid">
                    <a href="{{ route('admin.users.create') }}" class="qa-btn">
                        <div class="qa-icon">➕</div>
                        <div>
                            <div style="font-weight:600;font-size:.8rem;">Tambah User</div>
                            <div style="font-size:.7rem;color:var(--muted);">Siswa / Guru</div>
                        </div>
                    </a>
                    <a href="{{ route('admin.mitra.index') }}" class="qa-btn">
                        <div class="qa-icon">🏢</div>
                        <div>
                            <div style="font-weight:600;font-size:.8rem;">Mitra Baru</div>
                            <div style="font-size:.7rem;color:var(--muted);">DU / DI</div>
                        </div>
                    </a>
                    <a href="{{ route('admin.pkl.index') }}?status=pending" class="qa-btn">
                        <div class="qa-icon">📋</div>
                        <div>
                            <div style="font-weight:600;font-size:.8rem;">Review PKL</div>
                            <div style="font-size:.7rem;color:var(--muted);">{{ $pengajuanPending }} pending</div>
                        </div>
                    </a>
                    <a href="{{ route('admin.laporan.index') }}?status=pending" class="qa-btn">
                        <div class="qa-icon">📄</div>
                        <div>
                            <div style="font-weight:600;font-size:.8rem;">Laporan</div>
                            <div style="font-size:.7rem;color:var(--muted);">{{ $laporanPending }} pending</div>
                        </div>
                    </a>
                    <a href="{{ route('admin.jurnal.index') }}?status=pending" class="qa-btn">
                        <div class="qa-icon">📓</div>
                        <div>
                            <div style="font-weight:600;font-size:.8rem;">Validasi Jurnal</div>
                            <div style="font-size:.7rem;color:var(--muted);">{{ $jurnalPending }} pending</div>
                        </div>
                    </a>
                    <a href="{{ route('admin.log.index') }}" class="qa-btn">
                        <div class="qa-icon">🕐</div>
                        <div>
                            <div style="font-weight:600;font-size:.8rem;">Log Sistem</div>
                            <div style="font-size:.7rem;color:var(--muted);">Semua aktivitas</div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>

</main>

<script>
    // ── Sidebar mobile ──────────────────────
    function openSidebar() {
        document.getElementById('sidebar').classList.add('open');
        document.getElementById('overlay').classList.add('show');
    }
    function closeSidebar() {
        document.getElementById('sidebar').classList.remove('open');
        document.getElementById('overlay').classList.remove('show');
    }

    // ── Progress bar animate ────────────────
    window.addEventListener('load', () => {
        document.querySelectorAll('.prog-fill').forEach(el => {
            const w = el.style.width;
            el.style.width = '0';
            setTimeout(() => { el.style.width = w; }, 300);
        });
    });

    // ── Chart Absensi (Donut) ───────────────
    (function () {
        const data = {
            hadir : {{ $absensiPerStatus['Hadir']->total  ?? 0 }},
            izin  : {{ $absensiPerStatus['Izin']->total   ?? 0 }},
            sakit : {{ $absensiPerStatus['Sakit']->total  ?? 0 }},
            alpa  : {{ $absensiPerStatus['Alpa']->total   ?? 0 }},
        };

        const ctx = document.getElementById('chartAbsensi').getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Hadir','Izin','Sakit','Alpa'],
                datasets: [{
                    data: [data.hadir, data.izin, data.sakit, data.alpa],
                    backgroundColor: ['#22c55e','#f59e0b','#3b82f6','#ef4444'],
                    borderWidth: 0,
                    hoverOffset: 6,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                cutout: '72%',
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: ctx => ` ${ctx.label}: ${ctx.parsed}`
                        }
                    }
                }
            }
        });
    })();
</script>
</body>
</html>
