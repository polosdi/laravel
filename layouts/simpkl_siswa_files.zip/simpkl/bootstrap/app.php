<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        // Daftarkan alias middleware CheckRole
        $middleware->alias([
            'role' => \App\Http\Middleware\CheckRole::class,
        ]);

        // Log aktivitas otomatis untuk semua route yang sudah login
        $middleware->appendToGroup('web', [
            \App\Http\Middleware\LogAktivitasMiddleware::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
