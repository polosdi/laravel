{{-- ═══════════════════════════════════════════
     resources/views/pembimbing/jurnal/index.blade.php
═══════════════════════════════════════════ --}}
@extends('layouts.pembimbing')
@section('title','Jurnal Harian Siswa')

@section('content')
<div class="pg-head">
    <div>
        <div class="breadcrumb"><a href="{{ route('pembimbing.dashboard') }}">Dashboard</a><span>/</span> Jurnal</div>
        <h2>📓 Jurnal Harian Siswa</h2>
    </div>
</div>

{{-- Filter --}}
<form method="GET" style="display:flex;gap:10px;margin-bottom:18px;flex-wrap:wrap;align-items:center">
    <select name="status" style="padding:8px 13px;border:1px solid var(--border);border-radius:10px;font-family:var(--font);font-size:.825rem;background:var(--card-bg);color:var(--text);outline:none">
        <option value="">Semua Status</option>
        <option value="pending" {{ request('status')=='pending'?'selected':'' }}>⏳ Pending</option>
        <option value="valid"   {{ request('status')=='valid'?'selected':'' }}>✅ Valid</option>
        <option value="tolak"   {{ request('status')=='tolak'?'selected':'' }}>❌ Ditolak</option>
    </select>
    <select name="siswa_id" style="padding:8px 13px;border:1px solid var(--border);border-radius:10px;font-family:var(--font);font-size:.825rem;background:var(--card-bg);color:var(--text);outline:none">
        <option value="">Semua Siswa</option>
        @foreach($daftarSiswa as $s)
        <option value="{{ $s->id }}" {{ request('siswa_id')==$s->id?'selected':'' }}>
            {{ $s->nama_depan }} {{ $s->nama_belakang }}
        </option>
        @endforeach
    </select>
    <input type="date" name="tanggal" value="{{ request('tanggal') }}"
           style="padding:8px 13px;border:1px solid var(--border);border-radius:10px;font-family:var(--font);font-size:.825rem;background:var(--card-bg);color:var(--text);outline:none">
    <button type="submit" class="btn btn-out btn-sm">🔍 Filter</button>
    <a href="{{ route('pembimbing.jurnal.index') }}" class="btn btn-out btn-sm">Reset</a>
</form>

<div class="card">
    <div class="tbl-wrap">
        <table>
            <thead>
                <tr>
                    <th>Siswa</th><th>Tanggal</th><th>Jam Masuk</th><th>Jam Keluar</th>
                    <th>Kegiatan</th><th>Foto</th><th>Status</th><th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            @forelse($jurnal as $j)
            <tr>
                <td>
                    <div style="font-weight:600;font-size:.825rem">{{ $j->siswa->nama_depan }} {{ $j->siswa->nama_belakang }}</div>
                    <div style="font-size:.7rem;color:var(--text-muted)">{{ $j->siswa->profilSiswa->kelas ?? '' }}</div>
                </td>
                <td style="font-weight:600;white-space:nowrap">{{ \Carbon\Carbon::parse($j->tanggal)->translatedFormat('d M Y') }}</td>
                <td>{{ $j->jam_masuk ?? '—' }}</td>
                <td>{{ $j->jam_keluar ?? '—' }}</td>
                <td style="max-width:200px">{{ Str::limit($j->kegiatan, 55) }}</td>
                <td>
                    @if($j->foto_kegiatan)
                        <a href="{{ Storage::url($j->foto_kegiatan) }}" target="_blank">
                            <img src="{{ Storage::url($j->foto_kegiatan) }}" style="width:34px;height:34px;object-fit:cover;border-radius:6px;border:1px solid var(--border)">
                        </a>
                    @else <span style="color:var(--text-muted)">—</span> @endif
                </td>
                <td>
                    @if($j->status_validasi==='valid') <span class="bdg bdg-ok">✅ Valid</span>
                    @elseif($j->status_validasi==='tolak') <span class="bdg bdg-err">❌ Ditolak</span>
                    @else <span class="bdg bdg-warn">⏳ Pending</span> @endif
                </td>
                <td>
                    <div style="display:flex;gap:6px">
                        <a href="{{ route('pembimbing.jurnal.show', $j->id) }}" class="btn btn-xs btn-out">👁️</a>
                        @if($j->status_validasi === 'pending')
                        <form method="POST" action="{{ route('pembimbing.jurnal.validasi', $j->id) }}">
                            @csrf
                            <input type="hidden" name="status" value="valid">
                            <button type="submit" class="btn btn-xs btn-ok">✅</button>
                        </form>
                        <form method="POST" action="{{ route('pembimbing.jurnal.validasi', $j->id) }}">
                            @csrf
                            <input type="hidden" name="status" value="tolak">
                            <button type="submit" class="btn btn-xs btn-del">❌</button>
                        </form>
                        @endif
                    </div>
                </td>
            </tr>
            @empty
            <tr><td colspan="8">
                <div class="empty"><div class="empty-ic">📓</div><p>Tidak ada jurnal ditemukan.</p></div>
            </td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($jurnal->hasPages())
    <div class="pagi">
        <span>{{ $jurnal->firstItem() }}–{{ $jurnal->lastItem() }} dari {{ $jurnal->total() }}</span>
        {{ $jurnal->links() }}
    </div>
    @endif
</div>
@endsection
