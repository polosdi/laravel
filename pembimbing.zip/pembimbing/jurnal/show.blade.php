@extends('layouts.pembimbing')
@section('title','Detail Jurnal')

@section('content')
<div class="pg-head">
    <div>
        <div class="breadcrumb">
            <a href="{{ route('pembimbing.jurnal.index') }}">Jurnal</a><span>/</span> Detail
        </div>
        <h2>📓 Detail Jurnal Harian</h2>
    </div>
    <a href="{{ route('pembimbing.jurnal.index') }}" class="btn btn-out btn-sm">← Kembali</a>
</div>

<div style="display:grid;grid-template-columns:1.4fr 1fr;gap:20px;max-width:980px">

    {{-- DETAIL JURNAL --}}
    <div class="card">
        <div class="card-head">
            <div class="card-title">📝 Isi Jurnal</div>
            @if($jurnal->status_validasi==='valid') <span class="bdg bdg-ok">✅ Valid</span>
            @elseif($jurnal->status_validasi==='tolak') <span class="bdg bdg-err">❌ Ditolak</span>
            @else <span class="bdg bdg-warn">⏳ Menunggu Validasi</span> @endif
        </div>
        <div class="card-body">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px">
                <div style="background:rgba(102,126,234,.06);border-radius:10px;padding:13px">
                    <div style="font-size:.68rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px">Tanggal</div>
                    <div style="font-weight:700;font-size:.875rem">{{ \Carbon\Carbon::parse($jurnal->tanggal)->translatedFormat('l, d F Y') }}</div>
                </div>
                <div style="background:rgba(102,126,234,.06);border-radius:10px;padding:13px">
                    <div style="font-size:.68rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px">Jam Kerja</div>
                    <div style="font-weight:700;font-size:.875rem">{{ $jurnal->jam_masuk ?? '—' }} — {{ $jurnal->jam_keluar ?? '—' }}</div>
                </div>
            </div>

            <div style="margin-bottom:16px">
                <div style="font-size:.73rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px">Kegiatan</div>
                <div style="font-size:.875rem;line-height:1.75;color:var(--text);background:var(--stat-bg);border-radius:10px;padding:14px;border:1px solid var(--border)">
                    {{ $jurnal->kegiatan }}
                </div>
            </div>

            @if($jurnal->foto_kegiatan)
            <div>
                <div style="font-size:.73rem;font-weight:700;color:var(--text-muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px">Foto Kegiatan</div>
                <img src="{{ Storage::url($jurnal->foto_kegiatan) }}"
                     style="width:100%;max-height:220px;object-fit:cover;border-radius:10px;border:1px solid var(--border)">
            </div>
            @endif

            @if($jurnal->komentar_pembimbing)
            <div style="margin-top:16px;background:rgba(102,126,234,.06);border-radius:10px;padding:13px;border-left:3px solid var(--primary)">
                <div style="font-size:.72rem;font-weight:700;color:var(--primary);margin-bottom:5px">Komentar Pembimbing</div>
                <div style="font-size:.825rem">{{ $jurnal->komentar_pembimbing }}</div>
            </div>
            @endif
        </div>
    </div>

    <div style="display:flex;flex-direction:column;gap:16px">
        {{-- INFO SISWA --}}
        <div class="card">
            <div class="card-head"><div class="card-title">👤 Info Siswa</div></div>
            <div class="card-body">
                <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px">
                    <div style="width:44px;height:44px;border-radius:50%;background:var(--grad);display:flex;align-items:center;justify-content:center;font-weight:700;color:#fff;font-size:.78rem;flex-shrink:0">
                        {{ strtoupper(substr($jurnal->siswa->nama_depan,0,1).substr($jurnal->siswa->nama_belakang,0,1)) }}
                    </div>
                    <div>
                        <div style="font-weight:700;font-size:.875rem">{{ $jurnal->siswa->nama_depan }} {{ $jurnal->siswa->nama_belakang }}</div>
                        <div style="font-size:.72rem;color:var(--text-muted)">{{ $jurnal->siswa->profilSiswa->kelas ?? '' }} — {{ $jurnal->siswa->profilSiswa->jurusan ?? '' }}</div>
                    </div>
                </div>
                <div style="font-size:.78rem;color:var(--text-muted)">NIS: {{ $jurnal->siswa->profilSiswa->nis ?? '—' }}</div>
            </div>
        </div>

        {{-- FORM VALIDASI --}}
        @if($jurnal->status_validasi === 'pending')
        <div class="card">
            <div class="card-head"><div class="card-title">⚡ Validasi Jurnal</div></div>
            <div class="card-body">
                <form method="POST" action="{{ route('pembimbing.jurnal.validasi', $jurnal->id) }}">
                    @csrf
                    <div class="form-grid">
                        <div class="fgrp">
                            <label>Komentar / Catatan</label>
                            <textarea name="komentar_pembimbing" rows="4"
                                placeholder="Tuliskan feedback untuk siswa (opsional)...">{{ old('komentar_pembimbing') }}</textarea>
                        </div>
                        <div style="display:flex;gap:10px">
                            <button type="submit" name="status" value="valid" class="btn btn-ok" style="flex:1;justify-content:center">✅ Validasi</button>
                            <button type="submit" name="status" value="tolak" class="btn btn-del" style="flex:1;justify-content:center">❌ Tolak</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        @else
        <div class="card">
            <div class="card-body" style="padding-top:20px">
                @if($jurnal->status_validasi==='valid')
                <div class="al al-ok" style="margin:0">✅ Jurnal ini sudah divalidasi</div>
                @else
                <div class="al al-err" style="margin:0">❌ Jurnal ini ditolak</div>
                @endif
                <form method="POST" action="{{ route('pembimbing.jurnal.validasi', $jurnal->id) }}" style="margin-top:12px">
                    @csrf
                    <div class="fgrp" style="margin-bottom:10px">
                        <label>Update Komentar</label>
                        <textarea name="komentar_pembimbing" rows="3">{{ $jurnal->komentar_pembimbing }}</textarea>
                    </div>
                    <div style="display:flex;gap:8px">
                        <button name="status" value="valid" class="btn btn-ok btn-sm">✅ Validasi</button>
                        <button name="status" value="tolak" class="btn btn-del btn-sm">❌ Tolak</button>
                    </div>
                </form>
            </div>
        </div>
        @endif
    </div>

</div>
@endsection
