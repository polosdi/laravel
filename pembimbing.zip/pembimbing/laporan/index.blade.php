{{-- ═══════════════════════════
     pembimbing/laporan/index.blade.php
═══════════════════════════ --}}
@extends('layouts.pembimbing')
@section('title','Laporan PKL Siswa')

@section('content')
<div class="pg-head">
    <div>
        <div class="breadcrumb"><a href="{{ route('pembimbing.dashboard') }}">Dashboard</a><span>/</span> Laporan</div>
        <h2>📄 Laporan PKL Siswa</h2>
    </div>
</div>

<form method="GET" style="display:flex;gap:10px;margin-bottom:18px;flex-wrap:wrap">
    <select name="status" style="padding:8px 13px;border:1px solid var(--border);border-radius:10px;font-family:var(--font);font-size:.825rem;background:var(--card-bg);color:var(--text);outline:none">
        <option value="">Semua Status</option>
        <option value="pending" {{ request('status')=='pending'?'selected':'' }}>Pending</option>
        <option value="disetujui" {{ request('status')=='disetujui'?'selected':'' }}>Disetujui</option>
        <option value="revisi" {{ request('status')=='revisi'?'selected':'' }}>Revisi</option>
    </select>
    <select name="jenis" style="padding:8px 13px;border:1px solid var(--border);border-radius:10px;font-family:var(--font);font-size:.825rem;background:var(--card-bg);color:var(--text);outline:none">
        <option value="">Semua Jenis</option>
        <option value="mingguan" {{ request('jenis')=='mingguan'?'selected':'' }}>Mingguan</option>
        <option value="akhir" {{ request('jenis')=='akhir'?'selected':'' }}>Akhir</option>
    </select>
    <button type="submit" class="btn btn-out btn-sm">🔍 Filter</button>
    <a href="{{ route('pembimbing.laporan.index') }}" class="btn btn-out btn-sm">Reset</a>
</form>

<div class="card">
    <div class="tbl-wrap">
        <table>
            <thead><tr><th>Siswa</th><th>Judul</th><th>Jenis</th><th>File</th><th>Dikirim</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody>
            @forelse($laporan as $l)
            <tr>
                <td style="font-weight:600">{{ $l->siswa->nama_depan }} {{ $l->siswa->nama_belakang }}</td>
                <td>{{ Str::limit($l->judul_laporan,45) }}</td>
                <td><span class="bdg bdg-info">{{ ucfirst($l->jenis_laporan) }}</span></td>
                <td>
                    @if($l->file_path)
                        <a href="{{ Storage::url($l->file_path) }}" target="_blank" class="btn btn-xs btn-out">📎 Unduh</a>
                    @else —@endif
                </td>
                <td style="font-size:.78rem;color:var(--text-muted)">{{ \Carbon\Carbon::parse($l->created_at)->format('d M Y') }}</td>
                <td>
                    @if($l->status_pembimbing==='disetujui') <span class="bdg bdg-ok">Disetujui</span>
                    @elseif($l->status_pembimbing==='revisi') <span class="bdg bdg-err">Revisi</span>
                    @else <span class="bdg bdg-warn">Pending</span> @endif
                </td>
                <td><a href="{{ route('pembimbing.laporan.show',$l->id) }}" class="btn btn-xs btn-out">👁️ Tinjau</a></td>
            </tr>
            @empty
            <tr><td colspan="7"><div class="empty"><div class="empty-ic">📄</div><p>Belum ada laporan.</p></div></td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($laporan->hasPages())<div class="pagi">{{ $laporan->links() }}</div>@endif
</div>
@endsection
