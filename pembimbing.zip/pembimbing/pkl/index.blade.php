@extends('layouts.pembimbing')
@section('title','Pengajuan PKL')

@section('content')
<div class="pg-head">
    <div>
        <div class="breadcrumb"><a href="{{ route('pembimbing.dashboard') }}">Dashboard</a><span>/</span> PKL</div>
        <h2>📋 Pengajuan PKL Siswa</h2>
    </div>
</div>

<form method="GET" style="display:flex;gap:10px;margin-bottom:18px">
    <select name="status" style="padding:8px 13px;border:1px solid var(--border);border-radius:10px;font-family:var(--font);font-size:.825rem;background:var(--card-bg);color:var(--text);outline:none">
        <option value="">Semua Status</option>
        <option value="pending" {{ request('status')=='pending'?'selected':'' }}>Pending</option>
        <option value="disetujui" {{ request('status')=='disetujui'?'selected':'' }}>Disetujui</option>
        <option value="ditolak" {{ request('status')=='ditolak'?'selected':'' }}>Ditolak</option>
    </select>
    <button type="submit" class="btn btn-out btn-sm">🔍 Filter</button>
    <a href="{{ route('pembimbing.pkl.index') }}" class="btn btn-out btn-sm">Reset</a>
</form>

<div class="card">
    <div class="tbl-wrap">
        <table>
            <thead><tr><th>Ketua</th><th>Perusahaan</th><th>Anggota</th><th>Tanggal Ajuan</th><th>Dokumen</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody>
            @forelse($pkl as $p)
            <tr>
                <td style="font-weight:600">{{ $p->ketua->nama_depan }} {{ $p->ketua->nama_belakang }}</td>
                <td>
                    <div style="font-weight:600;font-size:.825rem">{{ $p->nama_perusahaan }}</div>
                    <div style="font-size:.72rem;color:var(--text-muted)">{{ Str::limit($p->alamat_perusahaan,40) }}</div>
                </td>
                <td>{{ $p->anggota->count() }} siswa</td>
                <td style="font-size:.78rem;color:var(--text-muted)">{{ \Carbon\Carbon::parse($p->tanggal_pengajuan)->format('d M Y') }}</td>
                <td>
                    @if($p->file_dokumen)
                        <a href="{{ Storage::url($p->file_dokumen) }}" target="_blank" class="btn btn-xs btn-out">📎</a>
                    @else <span style="color:var(--text-muted)">—</span> @endif
                </td>
                <td>
                    @if($p->status_pembimbing==='disetujui') <span class="bdg bdg-ok">Disetujui</span>
                    @elseif($p->status_pembimbing==='ditolak') <span class="bdg bdg-err">Ditolak</span>
                    @else <span class="bdg bdg-warn">Pending</span> @endif
                </td>
                <td>
                    <div style="display:flex;gap:6px">
                        @if($p->status_pembimbing === 'pending')
                        <form method="POST" action="{{ route('pembimbing.pkl.setujui', $p->id) }}">
                            @csrf
                            <button class="btn btn-xs btn-ok">✅ Setujui</button>
                        </form>
                        <form method="POST" action="{{ route('pembimbing.pkl.tolak', $p->id) }}">
                            @csrf
                            <button class="btn btn-xs btn-del">❌ Tolak</button>
                        </form>
                        @else
                        <span style="font-size:.75rem;color:var(--text-muted)">Sudah diproses</span>
                        @endif
                    </div>
                </td>
            </tr>
            @empty
            <tr><td colspan="7"><div class="empty"><div class="empty-ic">📋</div><p>Belum ada pengajuan PKL.</p></div></td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($pkl->hasPages())<div class="pagi">{{ $pkl->links() }}</div>@endif
</div>
@endsection
